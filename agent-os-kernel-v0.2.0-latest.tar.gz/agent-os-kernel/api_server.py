# -*- coding: utf-8 -*-
"""
Agent-OS-Kernel REST API Server
提供 HTTP API 接口
"""

import json
import logging
from flask import Flask, request, jsonify
from typing import Dict, Any

from agent_os_kernel import AgentOSKernel

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
kernel = None


def get_kernel() -> AgentOSKernel:
    """获取或创建内核实例"""
    global kernel
    if kernel is None:
        kernel = AgentOSKernel()
    return kernel


@app.route('/')
def index():
    """API 首页"""
    return jsonify({
        'name': 'Agent-OS-Kernel API',
        'version': '0.2.0',
        'endpoints': {
            'GET /': 'API 信息',
            'GET /health': '健康检查',
            'GET /api/kernel': '内核状态',
            'POST /api/agent': '创建 Agent',
            'GET /api/agent/<pid>': 'Agent 状态',
            'DELETE /api/agent/<pid>': '终止 Agent',
            'POST /api/checkpoint': '创建检查点',
            'POST /api/restore': '恢复检查点',
            'GET /api/metrics': 'Prometheus 指标',
            'GET /api/metrics/json': 'JSON 格式指标',
        }
    })


@app.route('/health')
def health():
    """健康检查"""
    return jsonify({
        'status': 'ok',
        'service': 'agent-os-kernel-api'
    })


@app.route('/api/kernel', methods=['GET'])
def get_kernel_status():
    """获取内核状态"""
    k = get_kernel()
    return jsonify({
        'version': k.version,
        'agents_count': len(k.scheduler.processes),
        'metrics': k.metrics.to_json()
    })


@app.route('/api/agent', methods=['POST'])
def create_agent():
    """创建 Agent"""
    data = request.json or {}
    
    name = data.get('name', f'Agent-{len(get_kernel().scheduler.processes)}')
    task = data.get('task', 'Default task')
    priority = data.get('priority', 50)
    
    k = get_kernel()
    pid = k.spawn_agent(name, task, priority)
    
    logger.info(f"Created agent: {pid}")
    
    return jsonify({
        'success': True,
        'pid': pid,
        'name': name,
        'task': task
    })


@app.route('/api/agent/<pid>', methods=['GET'])
def get_agent_status(pid: str):
    """获取 Agent 状态"""
    k = get_kernel()
    status = k.get_agent_status(pid)
    
    if status:
        return jsonify({
            'success': True,
            'status': status
        })
    else:
        return jsonify({
            'success': False,
            'error': 'Agent not found'
        }), 404


@app.route('/api/agent/<pid>', methods=['DELETE'])
def terminate_agent(pid: str):
    """终止 Agent"""
    k = get_kernel()
    k.terminate_agent(pid)
    
    return jsonify({
        'success': True,
        'pid': pid
    })


@app.route('/api/checkpoint', methods=['POST'])
def create_checkpoint():
    """创建检查点"""
    data = request.json or {}
    pid = data.get('pid')
    description = data.get('description', 'API checkpoint')
    
    if not pid:
        return jsonify({
            'success': False,
            'error': 'pid is required'
        }), 400
    
    k = get_kernel()
    checkpoint_id = k.create_checkpoint(pid, description)
    
    return jsonify({
        'success': True,
        'checkpoint_id': checkpoint_id
    })


@app.route('/api/restore', methods=['POST'])
def restore_checkpoint():
    """恢复检查点"""
    data = request.json or {}
    checkpoint_id = data.get('checkpoint_id')
    
    if not checkpoint_id:
        return jsonify({
            'success': False,
            'error': 'checkpoint_id is required'
        }), 400
    
    k = get_kernel()
    new_pid = k.restore_checkpoint(checkpoint_id)
    
    return jsonify({
        'success': True,
        'new_pid': new_pid,
        'checkpoint_id': checkpoint_id
    })


@app.route('/api/metrics', methods=['GET'])
def get_prometheus_metrics():
    """获取 Prometheus 格式指标"""
    k = get_kernel()
    return k.metrics.to_prometheus(), 200, {'Content-Type': 'text/plain'}


@app.route('/api/metrics/json', methods=['GET'])
def get_json_metrics():
    """获取 JSON 格式指标"""
    k = get_kernel()
    return jsonify(k.metrics.to_json())


@app.route('/api/tools', methods=['GET'])
def list_tools():
    """列出所有工具"""
    k = get_kernel()
    tools = k.tool_registry.list_tools()
    return jsonify({
        'success': True,
        'tools': tools
    })


@app.route('/api/tool/<name>', methods=['POST'])
def execute_tool(name: str):
    """执行工具"""
    k = get_kernel()
    params = request.json or {}
    
    result = k.execute_tool(name, **params)
    
    return jsonify({
        'success': True,
        'tool': name,
        'result': result
    })


@app.errorhandler(Exception)
def handle_error(error):
    """错误处理"""
    logger.error(f"API Error: {error}")
    return jsonify({
        'success': False,
        'error': str(error)
    }), 500


def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Agent-OS-Kernel API Server')
    parser.add_argument('--host', default='0.0.0.0', help='Host to bind')
    parser.add_argument('--port', type=int, default=8090, help='Port to listen')
    parser.add_argument('--debug', action='store_true', help='Debug mode')
    
    args = parser.parse_args()
    
    print(f"\n{'='*60}")
    print("Agent-OS-Kernel REST API Server")
    print(f"{'='*60}")
    print(f"API: http://{args.host}:{args.port}")
    print(f"Health: http://{args.host}:{args.port}/health")
    print(f"Endpoints: http://{args.host}:{args.port}/")
    print(f"{'='*60}\n")
    
    app.run(host=args.host, port=args.port, debug=args.debug)


if __name__ == '__main__':
    main()
