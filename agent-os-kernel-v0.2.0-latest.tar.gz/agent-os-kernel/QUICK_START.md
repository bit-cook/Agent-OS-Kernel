# 🚀 Agent-OS-Kernel 快速开始

## 安装

```bash
# 从源码安装
git clone https://github.com/bit-cook/Agent-OS-Kernel.git
cd Agent-OS-Kernel
pip install -e .

# 仅安装核心功能
pip install -e .
```

## 快速使用

```python
from agent_os_kernel import AgentOSKernel

# 初始化内核
kernel = AgentOSKernel()

# 创建 Agent
agent_pid = kernel.spawn_agent(
    name="ResearchAgent",
    task="研究 AI Agent 架构设计",
    priority=50
)

# 运行内核
kernel.run(max_iterations=10)

# 查看结果
status = kernel.get_agent_status(agent_pid)
print(status)
```

## Web UI

启动 Web 管理界面：

```bash
python web_server.py --host 0.0.0.0 --port 8090
```

访问: http://localhost:8090

## REST API

启动 API 服务器：

```bash
python api_server.py --host 0.0.0.0 --port 8090
```

### API 端点

| 方法 | 端点 | 描述 |
|------|------|------|
| GET | `/api/kernel` | 内核状态 |
| POST | `/api/agent` | 创建 Agent |
| GET | `/api/agent/<pid>` | Agent 状态 |
| DELETE | `/api/agent/<pid>` | 终止 Agent |
| POST | `/api/checkpoint` | 创建检查点 |
| POST | `/api/restore` | 恢复检查点 |
| GET | `/api/metrics` | Prometheus 指标 |
| GET | `/api/tools` | 工具列表 |

### API 使用示例

```bash
# 创建 Agent
curl -X POST http://localhost:8090/api/agent \
  -H "Content-Type: application/json" \
  -d '{"name": "TestAgent", "task": "Hello world"}'

# 获取 Agent 状态
curl http://localhost:8090/api/agent/agent-xxx

# 获取指标
curl http://localhost:8090/api/metrics
```

## 命令行工具

```bash
# 初始化项目
kernel init my_project

# 运行内核
kernel run

# 创建 Agent
kernel agent create my_agent "My task"

# 查看 Agent 列表
kernel agent list
```

## Docker 部署

```bash
# 开发模式
docker-compose up -d

# 生产模式
docker build -t agent-os-kernel .
docker run -p 8090:8090 agent-os-kernel
```

## 示例

查看 `examples/` 目录：

- `quick_start.py` - 快速开始示例
- `basic_usage.py` - 基础使用
- `distributed.py` - 分布式 Agent
- `postgresql_full.py` - PostgreSQL 集成

## 监控

访问进度页面: http://167.71.212.130:8088/progress.html

## 下一步

- 阅读 [API 参考](API_REFERENCE.md)
- 查看 [部署指南](DEPLOYMENT.md)
- 运行基准测试: `python benchmarks/performance.py --quick`
