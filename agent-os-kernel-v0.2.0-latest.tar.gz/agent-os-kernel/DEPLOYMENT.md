# Agent-OS-Kernel 部署指南

## 目录

1. [pip 安装](#pip-安装)
2. [Docker 部署](#docker-部署)
3. [Kubernetes 部署](#kubernetes-部署)
4. [生产环境配置](#生产环境配置)
5. [监控与告警](#监控与告警)
6. [故障排查](#故障排查)

---

## pip 安装

### 基础安装

```bash
pip install agent-os-kernel
```

### 完整功能

```bash
pip install agent-os-kernel[all]
```

这将安装所有依赖，包括：
- PostgreSQL 支持
- OpenAI 集成
- Anthropic/Claude 集成
- 开发工具

### 仅核心功能

```bash
pip install agent-os-kernel[cli]
```

---

## Docker 部署

### 使用官方镜像

```bash
docker pull agent-os-kernel:latest
docker run -d \
  --name agent-os-kernel \
  -p 8080:8080 \
  -v $(pwd)/config.yaml:/app/config.yaml \
  agent-os-kernel:latest
```

### Docker Compose

```bash
git clone https://github.com/bit-cook/Agent-OS-Kernel.git
cd Agent-OS-Kernel
docker-compose up -d
```

这将启动：
- Agent-OS-Kernel 服务
- PostgreSQL 数据库
- Prometheus 监控
- Grafana 仪表板

### 自定义构建

```bash
docker build -t my-agent-kernel .
docker run -d \
  --name my-agent-kernel \
  -p 8080:8080 \
  -e AGENT_OS_STORAGE_TYPE=postgresql \
  -e AGENT_OS_DB_CONNECTION_STRING=postgresql://user:pass@db:5432/agent_os \
  my-agent-kernel
```

---

## Kubernetes 部署

### 1. 创建 Namespace

```yaml
# namespace.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: agent-os
```

```bash
kubectl apply -f namespace.yaml
```

### 2. 创建 ConfigMap

```yaml
# configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: agent-os-config
  namespace: agent-os
data:
  config.yaml: |
    context:
      max_context_tokens: 128000
    scheduler:
      time_slice: 60.0
      max_concurrent_agents: 10
    storage:
      type: postgresql
    metrics:
      enabled: true
      port: 9090
```

### 3. 创建 Deployment

```yaml
# deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: agent-os-kernel
  namespace: agent-os
spec:
  replicas: 3
  selector:
    matchLabels:
      app: agent-os-kernel
  template:
    metadata:
      labels:
        app: agent-os-kernel
    spec:
      containers:
      - name: kernel
        image: agent-os-kernel:latest
        ports:
        - containerPort: 8080
        - containerPort: 9090
        env:
        - name: AGENT_OS_DB_CONNECTION_STRING
          valueFrom:
            secretKeyRef:
              name: db-credentials
              key: connection_string
        resources:
          requests:
            memory: "512Mi"
            cpu: "500m"
          limits:
            memory: "2Gi"
            cpu: "2000m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 8080
          initialDelaySeconds: 10
          periodSeconds: 5
```

### 4. 创建 Service

```yaml
# service.yaml
apiVersion: v1
kind: Service
metadata:
  name: agent-os-kernel
  namespace: agent-os
spec:
  selector:
    app: agent-os-kernel
  ports:
  - port: 8080
    targetPort: 8080
    name: http
  - port: 9090
    targetPort: 9090
    name: metrics
  type: ClusterIP
```

### 5. 创建 Ingress

```yaml
# ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: agent-os-kernel
  namespace: agent-os
  annotations:
    nginx.ingress.kubernetes.io/proxy-body-size: "50m"
spec:
  rules:
  - host: kernel.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: agent-os-kernel
            port:
              number: 8080
```

### 6. 部署

```bash
kubectl apply -f configmap.yaml
kubectl apply -f deployment.yaml
kubectl apply -f service.yaml
kubectl apply -f ingress.yaml
kubectl rollout status deployment/agent-os-kernel -n agent-os
```

---

## 生产环境配置

### PostgreSQL 配置

```yaml
storage:
  type: postgresql
  connection_string: postgresql://user:password@host:5432/agent_os
  pool_size: 20
  max_overflow: 40
```

### 资源配额

```yaml
scheduler:
  max_concurrent_agents: 50
  quota_window_seconds: 3600
  max_tokens_per_window: 1000000
  max_api_calls_per_window: 10000
```

### 安全配置

```yaml
security:
  enable_sandbox: true
  sandbox_type: docker
  allowed_tools:
    - "*"
  disallowed_tools:
    - delete_file
    - execute_command
  max_file_size_mb: 100
  network_policy: restricted
```

### 监控配置

```yaml
metrics:
  enabled: true
  port: 9090
  path: /metrics
  include_tokens: true
  include_latency: true
  include_custom: true
```

---

## 监控与告警

### Prometheus 配置

```yaml
scrape_configs:
  - job_name: 'agent-os-kernel'
    static_configs:
      - targets: ['localhost:9090']
    metrics_path: /metrics
```

### Grafana Dashboard

导入官方 Dashboard：
```bash
# 在 Grafana 中
1. 点击 "+" 按钮
2. 选择 "Import"
3. 输入 Dashboard ID: agent-os-kernel
```

### 关键指标

| 指标 | 描述 | 告警阈值 |
|------|------|----------|
| `agent_os_agents_active` | 活跃 Agent 数 | > 100 |
| `agent_os_api_latency_ms` | API 延迟 | > 5000ms |
| `agent_os_api_calls_errors_total` | API 错误数 | > 10/min |
| `agent_os_tokens_input_total` | Token 使用率 | > 80% |

### Alertmanager 配置

```yaml
route:
  group_by: ['alertname']
  receiver: 'default'
receivers:
- name: 'default'
  webhook_configs:
  - url: 'http://alertmanager:9093/api/v1/alerts'
inhibit_rules:
  - source_match:
      severity: 'critical'
    target_match:
      severity: 'warning'
    equal: ['alertname']
```

---

## 故障排查

### 服务无法启动

```bash
# 检查日志
kubectl logs -n agent-os deployment/agent-os-kernel

# 检查配置
kubectl exec -n agent-os <pod-name> -- cat /app/config.yaml

# 检查资源
kubectl top pods -n agent-os
```

### 数据库连接失败

```bash
# 测试连接
kubectl exec -n agent-os <pod-name> -- python -c "from agent_os_kernel import StorageManager; s = StorageManager('postgresql://...'); s.backend.test_connection()"
```

### 性能问题

```bash
# 查看慢查询
kubectl exec -n agent-os <pod-name> -- psql -c "SELECT * FROM pg_stat_statements ORDER BY mean_time DESC LIMIT 10;"

# 查看内存使用
kubectl top pods -n agent-os
```

### 常见错误

| 错误 | 原因 | 解决方案 |
|------|------|----------|
| `ContextOverflow` | 上下文超出限制 | 增加 `max_context_tokens` |
| `StorageConnectionFailed` | 数据库连接失败 | 检查连接字符串 |
| `ToolNotFound` | 工具不存在 | 检查工具注册 |
| `SecurityViolation` | 安全策略阻止 | 调整安全配置 |

---

## 备份与恢复

### 备份

```bash
# 备份 PostgreSQL
pg_dump -h host -U user agent_os > backup.sql

# 备份检查点
kubectl exec -n agent-os <pod-name> -- tar czf /tmp/checkpoints.tar.gz /app/checkpoints
kubectl cp agent-os/<pod-name>:/tmp/checkpoints.tar.gz ./checkpoints.tar.gz
```

### 恢复

```bash
# 恢复 PostgreSQL
psql -h host -U user agent_os < backup.sql

# 恢复检查点
kubectl cp ./checkpoints.tar.gz agent-os/<pod-name>:/tmp/checkpoints.tar.gz
kubectl exec -n agent-os <pod-name> -- tar xzf /tmp/checkpoints.tar.gz -C /app/
```

---

## 滚动更新

```bash
# 更新镜像
kubectl set image deployment/agent-os-kernel kernel=agent-os-kernel:v0.3.0 -n agent-os

# 查看更新状态
kubectl rollout status deployment/agent-os-kernel -n agent-os

# 回滚（如需要）
kubectl rollout undo deployment/agent-os-kernel -n agent-os
```
