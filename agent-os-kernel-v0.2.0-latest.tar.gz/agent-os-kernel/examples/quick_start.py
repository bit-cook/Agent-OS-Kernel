# -*- coding: utf-8 -*-
"""
Agent-OS-Kernel 快速上手指南

安装和基本使用示例
"""

# 安装
# pip install agent-os-kernel

# ========== 基础示例 ==========
from agent_os_kernel import AgentOSKernel, MetricsCollector
from agent_os_kernel.utils import (
    generate_id, 
    format_duration, 
    estimate_tokens,
    truncate_text,
    hash_text,
    ProgressTracker
)

# 初始化内核
kernel = AgentOSKernel()
print(f"✅ Kernel v{kernel.version} 初始化成功")

# ========== Agent 管理 ==========
agent_pid = kernel.spawn_agent(
    name="ResearchAssistant",
    task="研究最新的 AI Agent 架构设计",
    priority=50
)
print(f"🤖 Agent 创建: {agent_pid}")

# 查看 Agent 状态
status = kernel.get_agent_status(agent_pid)
print(f"状态: {status['state']}")

# ========== 检查点操作 ==========
checkpoint_id = kernel.create_checkpoint(agent_pid, "研究前快照")
print(f"💾 检查点: {checkpoint_id}")

# 从检查点恢复
new_pid = kernel.restore_checkpoint(checkpoint_id)
print(f"♻️ 恢复后 PID: {new_pid}")

# ========== 指标收集 ==========
metrics = kernel.metrics

# 记录 API 调用
metrics.record_api_call("claude", 150.0, success=True)
metrics.record_api_call("openai", 200.0, success=True)
metrics.record_api_call("claude", 180.0, success=False)  # 失败案例

# 记录 Token 使用
metrics.record_token_usage(1000, 500)

# 记录 Agent 生命周期
metrics.record_agent_created("agent-1")
metrics.record_agent_created("agent-2")
metrics.record_agent_terminated("agent-1")

# 获取 Prometheus 格式指标
print("\n📊 Prometheus 指标:")
print(metrics.to_prometheus()[:500])

# ========== 工具函数使用 ==========

# Token 估算
text = "这是一个测试文本，包含中英文混合内容"
tokens = estimate_tokens(text)
print(f"\n📝 Token 估算: {tokens}")

# 文本截断
long_text = "这是一段很长的文本..." * 100
truncated = truncate_text(long_text, 50)
print(f"✂️ 截断后长度: {len(truncated)} 字符")

# 进度追踪
tracker = ProgressTracker(100, "下载任务")
tracker.update(50)
print(f"\n📈 进度: {tracker.progress()*100:.1f}%")
print(f"⏱️ 预计剩余: {format_duration(tracker.eta())}")

# 生成唯一 ID
session_id = generate_session_id()
print(f"\n🔑 会话 ID: {session_id}")

# 文本哈希
content_hash = hash_text("重要数据")
print(f"🔒 内容哈希: {content_hash[:16]}...")

# ========== 配置管理 ==========
from agent_os_kernel.core.config import KernelConfig, DEFAULT_CONFIG

config = KernelConfig()
print(f"\n⚙️ 默认配置:")
print(f"   最大上下文 Token: {config.context.max_context_tokens}")
print(f"   时间片: {config.scheduler.time_slice}s")
print(f"   最大并发 Agent: {config.scheduler.max_concurrent_agents}")

# ========== 异常处理 ==========
from agent_os_kernel.core.exceptions import (
    KernelException,
    KernelErrorCode,
    ContextError,
    StorageError
)

try:
    # 模拟错误场景
    raise StorageError(
        "连接失败",
        error_code=KernelErrorCode.STORAGE_CONNECTION_FAILED,
        context={"host": "localhost", "port": 5432}
    )
except KernelException as e:
    print(f"\n❌ 异常捕获: {e.message}")
    print(f"   错误码: {e.error_code.name}")

# ========== 工具注册 ==========
from agent_os_kernel.tools.base import SimpleTool

# 自定义工具示例
class CalculatorTool(SimpleTool):
    def name(self) -> str:
        return "calculator"
    
    def description(self) -> str:
        return "简单计算器，支持加减乘除"
    
    def execute(self, expression: str) -> dict:
        try:
            result = eval(expression)  # 注意：生产环境需要更安全的实现
            return {"success": True, "result": result}
        except Exception as e:
            return {"success": False, "error": str(e)}

# 注册工具
calculator = CalculatorTool()
kernel.tool_registry.register(calculator)

# 使用工具
result = kernel.execute_tool("calculator", expression="2 + 3 * 4")
print(f"\n🔧 工具调用结果: {result}")

# ========== 运行内核 ==========
print("\n🚀 开始运行内核...")
kernel.run(max_iterations=5)

print("\n✅ 运行完成!")

# ========== 查看统计 ==========
stats = kernel.get_stats()
print(f"\n📊 最终统计:")
print(f"   总迭代次数: {stats.get('total_iterations', 0)}")
print(f"   活跃 Agent 数: {stats.get('active_agents', 0)}")
