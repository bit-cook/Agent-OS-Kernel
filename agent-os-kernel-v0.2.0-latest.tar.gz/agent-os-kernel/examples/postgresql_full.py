# -*- coding: utf-8 -*-
"""
PostgreSQL 完整集成示例
Agent-OS-Kernel + PostgreSQL + pgvector
"""

import os
from agent_os_kernel import AgentOSKernel
from agent_os_kernel.core.storage import (
    StorageManager, 
    PostgreSQLStorage,
    MemoryStorage
)

# ========== PostgreSQL 连接配置 ==========
POSTGRES_URL = os.environ.get(
    "POSTGRES_URL", 
    "postgresql://agent:agent_os@localhost:5432/agent_os"
)

def demo_postgresql_storage():
    """PostgreSQL 存储演示"""
    print("=" * 60)
    print("PostgreSQL 存储集成演示")
    print("=" * 60)
    
    # 方式 1: 直接使用 PostgreSQLStorage
    print("\n1. 直接连接 PostgreSQL:")
    storage = PostgreSQLStorage(
        connection_string=POSTGRES_URL,
        pool_size=10,
        max_overflow=20
    )
    
    # 测试连接
    print(f"   连接状态: {'✅ 成功' if storage.test_connection() else '❌ 失败'}")
    
    # 保存记忆
    memory_id = storage.save_memory(
        key="user:12345",
        data={
            "name": "张三",
            "preferences": {"theme": "dark", "language": "zh"},
            "chat_history": []
        },
        metadata={"source": "signup", "timestamp": "2024-02-06"}
    )
    print(f"   记忆 ID: {memory_id}")
    
    # 检索记忆
    memories = storage.retrieve_memories(
        query="用户偏好 主题",
        limit=5
    )
    print(f"   检索结果: {len(memories)} 条")
    
    # 保存进程状态
    process_state = {
        "pid": "agent-001",
        "name": "ResearchAgent",
        "state": "running",
        "checkpoint": 5
    }
    storage.save_process(process_state)
    print("   进程状态已保存")
    
    # 加载进程状态
    loaded = storage.load_process("agent-001")
    print(f"   加载状态: {loaded['name']} @ checkpoint {loaded['checkpoint']}")
    
    # 创建检查点
    checkpoint = {
        "checkpoint_id": "cp-001",
        "agent_pid": "agent-001",
        "timestamp": "2024-02-06T19:00:00Z",
        "state": process_state,
        "memories": [memory_id]
    }
    storage.save_checkpoint(checkpoint)
    print("   检查点已创建")
    
    # 审计日志
    storage.log_action(
        agent_id="agent-001",
        action="memory_save",
        resource="user:12345",
        result="success",
        metadata={"tokens": 150}
    )
    print("   审计日志已记录")
    
    return storage


def demo_vector_search():
    """向量搜索演示 (pgvector)"""
    print("\n" + "=" * 60)
    print("pgvector 向量搜索演示")
    print("=" * 60)
    
    # 检查 pgvector 是否可用
    try:
        import pgvector
        print("\n✅ pgvector 已安装")
    except ImportError:
        print("\n⚠️ pgvector 未安装，跳过向量搜索演示")
        print("   安装: pip install pgvector")
        return
    
    storage = PostgreSQLStorage(POSTGRES_URL)
    
    # 存储向量
    from agent_os_kernel.utils import hash_text
    import numpy as np
    
    # 模拟嵌入向量
    doc1_vector = np.random.rand(1536).astype('float32')
    doc2_vector = np.random.rand(1536).astype('float32')
    
    doc_id1 = storage.save_vector(
        document_id="doc:001",
        embedding=doc1_vector,
        metadata={"title": "AI Agent 入门", "content": "..."}
    )
    doc_id2 = storage.save_vector(
        document_id="doc:002",
        embedding=doc2_vector,
        metadata={"title": "深度学习", "content": "..."}
    )
    print(f"\n📄 向量文档已存储:")
    print(f"   ID 1: {doc_id1}")
    print(f"   ID 2: {doc_id2}")
    
    # 相似性搜索
    query_vector = np.random.rand(1536).astype('float32')
    results = storage.similarity_search(
        query_vector=query_vector,
        limit=5,
        threshold=0.7
    )
    print(f"\n🔍 相似性搜索结果: {len(results)} 条")
    
    # 混合检索
    hybrid_results = storage.hybrid_search(
        query="AI Agent 架构设计",
        query_vector=query_vector,
        limit=5,
        alpha=0.5  # 关键词:向量 权重
    )
    print(f"   混合检索: {len(hybrid_results)} 条")


def demo_coordination():
    """协调服务演示 (分布式锁/队列)"""
    print("\n" + "=" * 60)
    print("PostgreSQL 协调服务演示")
    print("=" * 60)
    
    storage = PostgreSQLStorage(POSTGRES_URL)
    
    # 1. 分布式锁
    print("\n🔒 分布式锁:")
    lock_id = storage.acquire_lock(
        name="agent_task_lock",
        owner="agent-001",
        timeout=300  # 5分钟
    )
    print(f"   锁 ID: {lock_id}")
    
    # 释放锁
    if lock_id:
        storage.release_lock(lock_id)
        print("   锁已释放")
    
    # 2. 任务队列
    print("\n📋 任务队列:")
    task_id = storage.enqueue_task(
        queue="agent_tasks",
        task={
            "agent_id": "agent-002",
            "action": "research",
            "params": {"topic": "AI Agent"}
        },
        priority=10
    )
    print(f"   任务已入队: {task_id}")
    
    # 获取任务
    task = storage.dequeue_task(queue="agent_tasks")
    print(f"   获取任务: {task['action']}")
    
    # 3. 事件通知
    print("\n📢 事件通知:")
    storage.publish_event(
        channel="agent_events",
        event={
            "type": "agent_created",
            "agent_id": "agent-003",
            "timestamp": "2024-02-06T19:00:00Z"
        }
    )
    print("   事件已发布")


def demo_audit_log():
    """审计日志演示"""
    print("\n" + "=" * 60)
    print("审计日志演示")
    print("=" * 60)
    
    storage = PostgreSQLStorage(POSTGRES_URL)
    
    # 记录各种操作
    actions = [
        ("agent-001", "memory_save", "user:123", "success"),
        ("agent-001", "tool_call", "calculator", "success"),
        ("agent-002", "checkpoint_create", "cp-001", "success"),
        ("agent-003", "api_call", "claude", "success"),
        ("agent-003", "api_call", "openai", "error"),
    ]
    
    print("\n📝 审计日志:")
    for agent, action, resource, result in actions:
        storage.log_action(
            agent_id=agent,
            action=action,
            resource=resource,
            result=result,
            metadata={"tokens": 100, "latency_ms": 150}
        )
        print(f"   ✓ {agent}: {action} -> {resource}")
    
    # 查询审计日志
    logs = storage.query_audit_logs(
        agent_id="agent-003",
        start_time="2024-02-06T00:00:00Z",
        end_time="2024-02-06T23:59:59Z",
        limit=10
    )
    print(f"\n   查询结果: {len(logs)} 条")
    
    # 安全审计
    security_issues = storage.query_audit_logs(
        result="error",
        action="security_violation",
        limit=100
    )
    print(f"   安全问题: {len(security_issues)} 条")


def demo_storage_manager():
    """StorageManager 便捷使用"""
    print("\n" + "=" * 60)
    print("StorageManager 便捷使用")
    print("=" * 60)
    
    # 自动检测连接字符串
    storage = StorageManager.from_postgresql(POSTGRES_URL)
    print("\n✅ StorageManager (PostgreSQL) 初始化成功")
    
    # 测试连接
    if storage.backend.test_connection():
        print("   连接测试: ✅ 通过")
    else:
        print("   连接测试: ❌ 失败")
        return
    
    # 便捷方法
    storage.save_memory("test:key", {"data": "test"})
    print("   save_memory: ✅")
    
    memories = storage.retrieve_memories("test")
    print(f"   retrieve_memories: ✅ ({len(memories)} 条)")


def main():
    """主函数"""
    print("\n" + "=" * 60)
    print("Agent-OS-Kernel PostgreSQL 集成演示")
    print("=" * 60)
    
    try:
        # PostgreSQL 基础功能
        storage = demo_postgresql_storage()
        
        # pgvector 向量搜索 (可选)
        demo_vector_search()
        
        # 协调服务
        demo_coordination()
        
        # 审计日志
        demo_audit_log()
        
        # 便捷使用
        demo_storage_manager()
        
        print("\n" + "=" * 60)
        print("✅ 所有演示完成!")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ 错误: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
