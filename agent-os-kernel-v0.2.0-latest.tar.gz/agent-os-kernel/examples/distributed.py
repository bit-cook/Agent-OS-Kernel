# -*- coding: utf-8 -*-
"""
分布式 Agent 示例
Agent-OS-Kernel 分布式调度和 IPC 通信
"""

import json
import time
import asyncio
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
import logging

from agent_os_kernel import AgentOSKernel
from agent_os_kernel.core.types import AgentState, ResourceQuota
from agent_os_kernel.core.scheduler import (
    AgentScheduler, 
    AgentProcess, 
    IPCChannel,
    MessageQueue
)

logger = logging.getLogger(__name__)


class MessageType(Enum):
    """消息类型"""
    TASK = "task"
    RESULT = "result"
    HEARTBEAT = "heartbeat"
    CONTROL = "control"
    SYNC = "sync"


@dataclass
class AgentMessage:
    """Agent 消息"""
    msg_type: MessageType
    from_agent: str
    to_agent: str
    payload: Dict[str, Any]
    timestamp: float = field(default_factory=time.time)
    message_id: str = field(default_factory=lambda: f"msg-{time.time_ns()}")
    priority: int = 0


class DistributedNode:
    """分布式节点"""
    
    def __init__(self, node_id: str, host: str = "localhost", port: int = 0):
        self.node_id = node_id
        self.host = host
        self.port = port
        self.kernel = AgentOSKernel()
        self.message_queue = MessageQueue()
        self.peers: Dict[str, 'DistributedNode'] = {}
        self.running = False
        
        # 注册本地 Agent
        self.kernel.spawn_agent(
            name=f"coordinator-{node_id}",
            task="协调本地 Agent 执行",
            priority=100
        )
    
    def register_peer(self, peer: 'DistributedNode'):
        """注册对等节点"""
        self.peers[peer.node_id] = peer
        logger.info(f"Registered peer: {peer.node_id}")
    
    async def send_message(self, message: AgentMessage):
        """发送消息到其他节点"""
        if message.to_agent in self.peers:
            await self.peers[message.to_agent].receive_message(message)
        else:
            # 发送到本地
            self.message_queue.put(message)
    
    async def receive_message(self, message: AgentMessage):
        """接收消息"""
        self.message_queue.put(message)
        logger.debug(f"Received message: {message.msg_type.value}")
    
    async def broadcast(self, message: AgentMessage):
        """广播消息到所有节点"""
        for peer in self.peers.values():
            await self.send_message(message)
    
    def get_local_agents(self) -> List[str]:
        """获取本地 Agent 列表"""
        return list(self.kernel.scheduler.processes.keys())
    
    async def route_task(self, task: Dict) -> str:
        """任务路由 - 选择最佳节点执行"""
        # 简单策略: 路由到负载最低的节点
        best_node = self
        min_load = float('inf')
        
        # 检查本地
        local_load = len(self.kernel.scheduler.processes)
        if local_load < min_load:
            min_load = local_load
            best_node = self
        
        # 检查对等节点
        for node_id, peer in self.peers.items():
            peer_load = len(peer.kernel.scheduler.processes)
            if peer_load < min_load:
                min_load = peer_load
                best_node = peer
        
        return best_node.node_id
    
    async def execute_distributed(self, task: Dict) -> Dict:
        """分布式任务执行"""
        # 1. 路由任务
        target_node = await self.route_task(task)
        logger.info(f"Routing task to: {target_node}")
        
        # 2. 如果是本地执行
        if target_node == self.node_id:
            return await self._execute_local(task)
        
        # 3. 否则发送到远程
        message = AgentMessage(
            msg_type=MessageType.TASK,
            from_agent=self.node_id,
            to_agent=target_node,
            payload=task
        )
        await self.broadcast(message)
        
        # 4. 等待结果
        result = await self._wait_for_result(task.get("task_id"))
        return result
    
    async def _execute_local(self, task: Dict) -> Dict:
        """本地执行任务"""
        agent_pid = self.kernel.spawn_agent(
            name=task.get("name", "DistributedAgent"),
            task=task.get("description", "执行分布式任务"),
            priority=50
        )
        
        # 创建检查点
        checkpoint_id = self.kernel.create_checkpoint(
            agent_pid,
            f"Task: {task.get('task_id', 'unknown')}"
        )
        
        return {
            "status": "completed",
            "agent_pid": agent_pid,
            "checkpoint_id": checkpoint_id,
            "node_id": self.node_id
        }
    
    async def _wait_for_result(self, task_id: str, timeout: float = 30.0) -> Dict:
        """等待任务结果"""
        start = time.time()
        while time.time() - start < timeout:
            # 检查消息队列
            while not self.message_queue.empty():
                message = self.message_queue.get()
                if (message.msg_type == MessageType.RESULT and 
                    message.payload.get("task_id") == task_id):
                    return message.payload
            await asyncio.sleep(0.1)
        
        return {"status": "timeout", "task_id": task_id}


class SharedStateManager:
    """共享状态管理器 (基于 PostgreSQL)"""
    
    def __init__(self, storage_url: str):
        self.storage_url = storage_url
        self.local_cache: Dict[str, Any] = {}
    
    async def get(self, key: str) -> Optional[Any]:
        """获取共享状态"""
        # 先查本地缓存
        if key in self.local_cache:
            return self.local_cache[key]
        
        # 从存储加载
        # 这里应该调用 PostgreSQL storage
        # 简化示例
        return None
    
    async def set(self, key: str, value: Any, ttl: float = None):
        """设置共享状态"""
        self.local_cache[key] = value
        
        # 同步到存储
        # 这里应该调用 PostgreSQL storage
        logger.info(f"Shared state set: {key}")
    
    async def delete(self, key: str):
        """删除共享状态"""
        if key in self.local_cache:
            del self.local_cache[key]
        logger.info(f"Shared state deleted: {key}")


async def demo_distributed_agents():
    """分布式 Agent 演示"""
    print("\n" + "=" * 60)
    print("分布式 Agent 演示")
    print("=" * 60)
    
    # 创建多个节点
    print("\n1. 创建分布式节点:")
    node_a = DistributedNode(node_id="node-a", host="192.168.1.10", port=8080)
    node_b = DistributedNode(node_id="node-b", host="192.168.1.11", port=8080)
    node_c = DistributedNode(node_id="node-c", host="192.168.1.12", port=8080)
    
    print(f"   节点 A: {node_a.node_id} @ {node_a.host}")
    print(f"   节点 B: {node_b.node_id} @ {node_b.host}")
    print(f"   节点 C: {node_c.node_id} @ {node_c.host}")
    
    # 注册对等节点
    print("\n2. 建立节点连接:")
    node_a.register_peer(node_b)
    node_a.register_peer(node_c)
    node_b.register_peer(node_a)
    node_c.register_peer(node_a)
    print("   ✅ 所有节点已互联")
    
    # 任务路由
    print("\n3. 任务路由:")
    task = {
        "task_id": "task-001",
        "name": "ResearchAgent",
        "description": "研究分布式 AI Agent 系统",
        "priority": 50
    }
    
    best_node = await node_a.route_task(task)
    print(f"   任务路由到: {best_node}")
    
    # 分布式执行
    print("\n4. 分布式执行:")
    result = await node_a.execute_distributed(task)
    print(f"   执行结果: {result['status']}")
    print(f"   Agent PID: {result['agent_pid']}")
    print(f"   节点: {result['node_id']}")
    
    # 消息传递
    print("\n5. IPC 消息传递:")
    message = AgentMessage(
        msg_type=MessageType.CONTROL,
        from_agent="node-a",
        to_agent="node-b",
        payload={"command": "pause", "reason": "资源紧张"}
    )
    await node_a.send_message(message)
    print(f"   消息已发送: {message.msg_type.value}")
    
    # 获取节点状态
    print("\n6. 节点状态:")
    for node in [node_a, node_b, node_c]:
        agents = node.get_local_agents()
        print(f"   {node.node_id}: {len(agents)} 个 Agent")


async def demo_shared_state():
    """共享状态演示"""
    print("\n" + "=" * 60)
    print("共享状态管理演示")
    print("=" * 60)
    
    # 创建状态管理器
    state_mgr = SharedStateManager("postgresql://...")
    
    print("\n1. 设置共享状态:")
    await state_mgr.set("task:001", {"status": "running", "progress": 50})
    print("   ✅ task:001 = running (50%)")
    
    await state_mgr.set("resource:pool", {"available": 100, "used": 25})
    print("   ✅ resource:pool = 100 available, 25 used")
    
    print("\n2. 读取共享状态:")
    task_state = await state_mgr.get("task:001")
    print(f"   task:001 = {task_state}")
    
    print("\n3. 删除共享状态:")
    await state_mgr.delete("task:001")
    print("   ✅ 已删除")


def demo_ipc_channels():
    """IPC 通道演示"""
    print("\n" + "=" * 60)
    print("IPC 通道演示")
    print("=" * 60)
    
    # 创建通道
    print("\n1. 创建 IPC 通道:")
    channel = IPCChannel(
        name="agent-communication",
        max_buffer_size=1000,
        timeout=30.0
    )
    print(f"   通道: {channel.name}")
    
    # 发送消息
    print("\n2. 发送消息:")
    messages = [
        {"from": "agent-001", "to": "agent-002", "content": "Hello!"},
        {"from": "agent-001", "to": "agent-002", "content": "How are you?"},
        {"from": "agent-002", "to": "agent-001", "content": "I'm fine!"},
    ]
    for msg in messages:
        channel.send(msg)
        print(f"   ✓ {msg['from']} -> {msg['to']}: {msg['content']}")
    
    # 接收消息
    print("\n3. 接收消息:")
    while not channel.empty():
        msg = channel.receive(timeout=5.0)
        if msg:
            print(f"   ✓ {msg['from']}: {msg['content']}")
    
    # 消息队列
    print("\n4. 消息队列:")
    queue = MessageQueue(max_size=100)
    
    # 生产者
    for i in range(5):
        queue.put({"item": i, "data": f"item-{i}"})
        print(f"   ✓ 生产: item-{i}")
    
    # 消费者
    while not queue.empty():
        item = queue.get()
        print(f"   ✓ 消费: {item['data']}")


async def main():
    """主函数"""
    # 配置日志
    logging.basicConfig(level=logging.INFO)
    
    print("\n" + "=" * 60)
    print("Agent-OS-Kernel 分布式功能演示")
    print("=" * 60)
    
    try:
        # IPC 通道
        demo_ipc_channels()
        
        # 分布式 Agent
        await demo_distributed_agents()
        
        # 共享状态
        await demo_shared_state()
        
        print("\n" + "=" * 60)
        print("✅ 分布式演示完成!")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ 错误: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())
