# Agent-OS-Kernel Changelog

## [Unreleased]

## [0.2.0] - 2024-02-06

### Added
- **Configuration Module** (`agent_os_kernel/core/config.py`)
  - YAML configuration support with `KernelConfig` class
  - Environment variable overrides via `EnvironmentConfigOverride`
  - JSON/YAML file loading with `ConfigLoader`
  - Nested config get/set operations
  - Validation for context tokens, time slice, concurrent agents

- **Exception Hierarchy** (`agent_os_kernel/core/exceptions.py`)
  - Comprehensive error codes (300+ codes)
  - Context errors, Storage errors, Scheduler errors
  - Tool errors, Security errors, API errors
  - Error code enum `KernelErrorCode`
  - Exception classes with context

- **Metrics Module** (`agent_os_kernel/core/metrics.py`)
  - Prometheus-compatible metrics collector
  - Counter, Gauge, Histogram support
  - Token usage, API latency, cache hit recording
  - Agent lifecycle event tracking
  - WSGI middleware for `/metrics` endpoint

- **Utils Module** (`agent_os_kernel/utils/__init__.py`)
  - Token estimation functions
  - Text processing utilities
  - JSON parsing helpers
  - ID generation (sessions, agents, checkpoints)
  - Time formatting and hashing utilities
  - Validation and file operations
  - Progress tracker

- **OpenAI Integration** (`agent_os_kernel/integrations/openai_integration.py`)
  - GPT-4/GPT-3.5-turbo support
  - Function calling (tools)
  - Streaming responses
  - Automatic retry with exponential backoff
  - Conversation cache for KV optimization

- **CLI** (`agent_os_kernel/cli.py`)
  - `kernel init` - Initialize new kernel project
  - `kernel run` - Run kernel
  - `kernel agent create|list|status` - Agent management
  - `kernel checkpoint create|restore` - Checkpoint operations
  - `kernel config show|set` - Configuration management
  - `kernel version` - Show version

- **Docker Support**
  - Multi-stage Dockerfile for production
  - docker-compose.yml with PostgreSQL, Prometheus, Grafana
  - Health checks and service configuration

- **PyPI Packaging** (`pyproject.toml`)
  - Setuptools build system
  - Optional dependencies (postgres, all, dev, cli)
  - Project metadata and URLs
  - Black, Ruff, MyPy, Pytest configuration

- **Comprehensive Tests**
  - `tests/test_config.py` - Configuration tests
  - `tests/test_metrics.py` - Metrics tests
  - `tests/test_utils.py` - Utilities tests
  - Enhanced fixtures and mock objects

### Changed
- Updated `requirements.txt` with new dependencies
- Improved error messages and logging
- Enhanced test coverage to >80%

### Fixed
- Various bugs in context manager
- Memory leak in scheduler
- Tool registry race conditions

## [0.1.0] - 2024-01-15

### Added
- Initial release
- Core kernel functionality
- Context management (virtual memory)
- Storage backend (PostgreSQL + memory)
- Agent scheduler with preemptive scheduling
- Tool system (Agent-Native CLI)
- Security sandboxing
- Claude integration example

### Known Issues
- Limited error recovery
- No checkpoint persistence
- Basic metrics only
