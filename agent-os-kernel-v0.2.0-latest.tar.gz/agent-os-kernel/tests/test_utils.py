# -*- coding: utf-8 -*-
"""
Tests for Utils Module - Agent OS Kernel Test Suite
"""

import pytest
import tempfile
import os
from pathlib import Path

from agent_os_kernel.utils import (
    # Token estimation
    estimate_tokens,
    estimate_tokens_messages,
    truncate_text,
    
    # Text processing
    normalize_whitespace,
    extract_code_blocks,
    
    # JSON helpers
    parse_json_safely,
    format_json,
    
    # ID generation
    generate_id,
    generate_session_id,
    generate_agent_id,
    generate_checkpoint_id,
    
    # Time utilities
    format_duration,
    format_timestamp,
    
    # Hashing
    hash_text,
    hash_dict,
    
    # Validation
    is_valid_url,
    is_valid_email,
    
    # File operations
    read_file_safely,
    write_file_safely,
    
    # Progress tracking
    ProgressTracker
)


class TestTokenEstimation:
    """Test token estimation functions"""
    
    def test_estimate_empty_string(self):
        """Test estimating empty string"""
        assert estimate_tokens("") == 0
        assert estimate_tokens(None) == 0
    
    def test_estimate_english_text(self):
        """Test estimating English text"""
        text = "This is a test sentence with several words"
        tokens = estimate_tokens(text)
        
        assert tokens > 0
        # Should be roughly equal to word count for English
        assert tokens <= len(text.split())
    
    def test_estimate_chinese_text(self):
        """Test estimating Chinese text"""
        text = "这是一个测试句子"
        tokens = estimate_tokens(text)
        
        assert tokens > 0
        # Chinese characters are ~0.5 tokens each
        assert tokens < len(text)
    
    def test_estimate_mixed_text(self):
        """Test estimating mixed English/Chinese text"""
        text = "Hello 世界 test 测试"
        tokens = estimate_tokens(text)
        
        assert tokens > 0
        assert tokens < len(text)
    
    def test_estimate_messages(self):
        """Test estimating message list token count"""
        messages = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi there!"},
            {"role": "user", "content": "How are you?"}
        ]
        
        tokens = estimate_tokens_messages(messages)
        
        assert tokens > 0
    
    def test_truncate_text(self):
        """Test text truncation"""
        text = "This is a long text with many words that should be truncated"
        
        truncated = truncate_text(text, 10)
        
        assert len(truncated) < len(text)
        # Should still be readable
        assert truncated.strip()
    
    def test_truncate_short_text(self):
        """Test truncation of short text"""
        text = "Short"
        
        truncated = truncate_text(text, 100)
        
        assert truncated == text
    
    def test_truncate_with_custom_tokenizer(self):
        """Test truncation with custom tokenizer"""
        text = "word1 word2 word3 word4 word5"
        
        def simple_tokenizer(t):
            return len(t.split())
        
        truncated = truncate_text(text, 3, tokenizer=simple_tokenizer)
        
        assert simple_tokenizer(truncated) <= 3


class TestTextProcessing:
    """Test text processing functions"""
    
    def test_normalize_whitespace(self):
        """Test whitespace normalization"""
        text = "This   is    a    test\n\nWith\tmultiple   spaces"
        
        normalized = normalize_whitespace(text)
        
        assert "  " not in normalized)
        assert "\n\n" not in normalized
        assert "\t" not in normalized
        assert normalized.strip() == text.strip()
    
    def test_extract_code_blocks(self):
        """Test extracting code blocks from markdown"""
        text = """
Here is some code:
```python
def hello():
    print("world")
```

And another:
```javascript
console.log("test");
```

End of text.
"""
        
        blocks = extract_code_blocks(text)
        
        assert len(blocks) == 2
        assert blocks[0]["language"] == "python"
        assert "def hello" in blocks[0]["code"]
        assert blocks[1]["language"] == "javascript"
        assert "console.log" in blocks[1]["code"]
    
    def test_extract_code_blocks_no_language(self):
        """Test extracting code blocks without language"""
        text = """
```
some plain code
```
"""
        
        blocks = extract_code_blocks(text)
        
        assert len(blocks) == 1
        assert blocks[0]["language"] == "text"
    
    def test_extract_no_code_blocks(self):
        """Test with no code blocks"""
        text = "Just plain text without code blocks"
        
        blocks = extract_code_blocks(text)
        
        assert len(blocks) == 0


class TestJSONHelpers:
    """Test JSON helper functions"""
    
    def test_parse_valid_json(self):
        """Test parsing valid JSON"""
        text = '{"key": "value", "number": 42}'
        
        data, error = parse_json_safely(text)
        
        assert error is None
        assert data["key"] == "value"
        assert data["number"] == 42
    
    def test_parse_json_with_code_block(self):
        """Test parsing JSON in markdown code block"""
        text = """
Here is some JSON:
```json
{"name": "test", "value": 123}
```
End.
"""
        
        data, error = parse_json_safely(text)
        
        assert error is None
        assert data["name"] == "test"
    
    def test_parse_invalid_json(self):
        """Test parsing invalid JSON"""
        text = '{"invalid": json}'
        
        data, error = parse_json_safely(text)
        
        assert data is None
        assert error is not None
    
    def test_format_json(self):
        """Test JSON formatting"""
        data = {"name": "test", "items": [1, 2, 3], "nested": {"key": "value"}}
        
        formatted = format_json(data, indent=2)
        
        assert "{" in formatted
        assert '"name": "test"' in formatted
        assert "  " in formatted  # Indentation


class TestIDGeneration:
    """Test ID generation functions"""
    
    def test_generate_id(self):
        """Test basic ID generation"""
        id1 = generate_id()
        id2 = generate_id()
        
        assert len(id1) == 8
        assert id1 != id2
    
    def test_generate_id_with_prefix(self):
        """Test ID generation with prefix"""
        id_with_prefix = generate_id("user_")
        
        assert id_with_prefix.startswith("user_")
        assert len(id_with_prefix) == 13  # 5 + 8
    
    def test_generate_session_id(self):
        """Test session ID generation"""
        session_id = generate_session_id()
        
        assert session_id.startswith("session-")
        assert len(session_id) == 17  # "session-" + 8 chars
    
    def test_generate_agent_id(self):
        """Test agent ID generation"""
        agent_id = generate_agent_id()
        
        assert agent_id.startswith("agent-")
        assert len(agent_id) == 13
    
    def test_generate_checkpoint_id(self):
        """Test checkpoint ID generation"""
        checkpoint_id = generate_checkpoint_id()
        
        assert checkpoint_id.startswith("cp-")


class TestTimeUtilities:
    """Test time utility functions"""
    
    def test_format_duration_seconds(self):
        """Test formatting seconds"""
        assert format_duration(30) == "30s"
        assert format_duration(59) == "59s"
    
    def test_format_duration_minutes(self):
        """Test formatting minutes"""
        assert format_duration(60) == "1m 0s"
        assert format_duration(150) == "2m 30s"
    
    def test_format_duration_hours(self):
        """Test formatting hours"""
        assert format_duration(3600) == "1h 0m"
        assert format_duration(7200) == "2h 0m"
        assert format_duration(3661) == "1h 1m 1s"
    
    def test_format_duration_days(self):
        """Test formatting days"""
        assert format_duration(86400) == "1d 0h"
        assert format_duration(90000) == "1d 1h 0m"
    
    def test_format_timestamp_iso(self):
        """Test ISO format timestamp"""
        timestamp = 1700000000
        
        formatted = format_timestamp(timestamp, format="iso")
        
        assert "T" in formatted  # ISO format has T separator
        assert ":" in formatted
    
    def test_format_timestamp_human(self):
        """Test human-readable timestamp"""
        timestamp = 1700000000
        
        formatted = format_timestamp(timestamp, format="human")
        
        assert "-" in formatted  # YYYY-MM-DD format
        assert ":" in formatted  # HH:MM:SS
    
    def test_format_timestamp_unix(self):
        """Test Unix timestamp"""
        timestamp = 1700000000
        
        formatted = format_timestamp(timestamp, format="unix")
        
        assert formatted == "1700000000"
    
    def test_format_timestamp_now(self):
        """Test timestamp with no argument (now)"""
        formatted = format_timestamp()
        
        assert formatted is not None
        assert len(formatted) > 0


class TestHashing:
    """Test hashing functions"""
    
    def test_hash_text(self):
        """Test text hashing"""
        hash1 = hash_text("hello")
        hash2 = hash_text("hello")
        hash3 = hash_text("world")
        
        assert hash1 == hash2
        assert hash1 != hash3
        assert len(hash1) == 64  # SHA-256 hex length
    
    def test_hash_dict(self):
        """Test dictionary hashing"""
        dict1 = {"key": "value", "number": 42}
        dict2 = {"key": "value", "number": 42}
        dict3 = {"key": "different"}
        
        hash1 = hash_dict(dict1)
        hash2 = hash_dict(dict2)
        hash3 = hash_dict(dict3)
        
        assert hash1 == hash2
        assert hash1 != hash3
    
    def test_hash_dict_order_independent(self):
        """Test that dict hashing is order-independent"""
        dict1 = {"a": 1, "b": 2, "c": 3}
        dict2 = {"c": 3, "a": 1, "b": 2}
        
        hash1 = hash_dict(dict1)
        hash2 = hash_dict(dict2)
        
        assert hash1 == hash2


class TestValidation:
    """Test validation functions"""
    
    def test_valid_url(self):
        """Test valid URL detection"""
        assert is_valid_url("https://example.com") is True
        assert is_valid_url("http://localhost:8080") is True
        assert is_valid_url("https://api.example.com/v1/users") is True
    
    def test_invalid_url(self):
        """Test invalid URL detection"""
        assert is_valid_url("not a url") is False
        assert is_valid_url("ftp://invalid.proto") is False
        assert is_valid_url("") is False
    
    def test_valid_email(self):
        """Test valid email detection"""
        assert is_valid_email("user@example.com") is True
        assert is_valid_email("test.user+tag@domain.org") is True
    
    def test_invalid_email(self):
        """Test invalid email detection"""
        assert is_valid_email("not.an.email") is False
        assert is_valid_email("@missing.local") is False
        assert is_valid_email("no_at_sign") is False


class TestFileOperations:
    """Test file operation functions"""
    
    def test_read_file_success(self):
        """Test successful file read"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write("test content")
            f.flush()
            
            try:
                content, error = read_file_safely(f.name)
                
                assert error is None
                assert content == "test content"
            finally:
                os.unlink(f.name)
    
    def test_read_file_not_found(self):
        """Test reading nonexistent file"""
        content, error = read_file_safely("/nonexistent/path/file.txt")
        
        assert content is None
        assert error is not None
        assert "not found" in error.lower()
    
    def test_write_file_success(self):
        """Test successful file write"""
        with tempfile.TemporaryDirectory() as tmpdir:
            filepath = os.path.join(tmpdir, "test.txt")
            
            success, error = write_file_safely(filepath, "new content")
            
            assert success is True
            assert error is None
            assert os.path.exists(filepath)
            
            with open(filepath, 'r') as f:
                assert f.read() == "new content"
    
    def test_write_file_permission_error(self):
        """Test writing to restricted path"""
        success, error = write_file_safely("/root/no_permission.txt", "content")
        
        assert success is False
        assert error is not None


class TestProgressTracker:
    """Test ProgressTracker class"""
    
    def test_initialization(self):
        """Test tracker initialization"""
        tracker = ProgressTracker(100, "Test Task")
        
        assert tracker.total == 100
        assert tracker.current == 0
        assert tracker.description == "Test Task"
    
    def test_update(self):
        """Test progress update"""
        tracker = ProgressTracker(100, "Test")
        
        tracker.update(25)
        
        assert tracker.current == 25
        assert tracker.progress() == 0.25
    
    def test_update_beyond_total(self):
        """Test updating beyond total"""
        tracker = ProgressTracker(100, "Test")
        
        tracker.update(150)
        
        assert tracker.current == 100
        assert tracker.progress() == 1.0
    
    def test_progress_value(self):
        """Test progress calculation"""
        tracker = ProgressTracker(100, "Test")
        
        tracker.update(33)
        
        assert 0.32 < tracker.progress() < 0.34
    
    def test_eta_calculation(self):
        """Test ETA calculation"""
        tracker = ProgressTracker(100, "Test")
        
        tracker.update(50)
        eta = tracker.eta()
        
        # ETA should be positive and reasonable
        assert eta >= 0
        # After 50%, ETA should be roughly equal to elapsed time
    
    def test_eta_zero_when_complete(self):
        """Test ETA is zero when complete"""
        tracker = ProgressTracker(100, "Test")
        
        tracker.update(100)
        eta = tracker.eta()
        
        assert eta == 0
    
    def test_str_representation(self):
        """Test string representation"""
        tracker = ProgressTracker(100, "Test")
        tracker.update(50)
        
        str_repr = str(tracker)
        
        assert "Test" in str_repr
        assert "50" in str_repr
        assert "50.0%" in str_repr
