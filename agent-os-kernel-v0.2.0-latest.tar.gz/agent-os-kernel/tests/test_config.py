# -*- coding: utf-8 -*-
"""
Tests for Configuration Module - Agent OS Kernel Test Suite
"""

import pytest
import tempfile
import os
from pathlib import Path

from agent_os_kernel.core.config import (
    KernelConfig,
    ConfigLoader,
    ConfigError,
    EnvironmentConfigOverride,
    DEFAULT_CONFIG
)


class TestKernelConfig:
    """Test KernelConfig class"""
    
    def test_default_config_values(self):
        """Test default configuration values"""
        config = KernelConfig()
        
        assert config.version == "0.2.0"
        assert config.max_context_tokens == 128000
        assert config.time_slice == 60.0
        assert config.max_concurrent_agents == 10
        assert config.storage_type == "memory"
        assert config.enable_metrics is True
        assert config.enable_security is True
    
    def test_config_from_dict(self):
        """Test creating config from dictionary"""
        data = {
            "max_context_tokens": 64000,
            "time_slice": 30.0,
            "max_concurrent_agents": 5,
            "custom_option": "test_value"
        }
        
        config = KernelConfig.from_dict(data)
        
        assert config.max_context_tokens == 64000
        assert config.time_slice == 30.0
        assert config.max_concurrent_agents == 5
        assert getattr(config, "custom_option", None) == "test_value"
    
    def test_config_to_dict(self):
        """Test converting config to dictionary"""
        config = KernelConfig()
        config.time_slice = 45.0
        config.max_context_tokens = 64000
        
        data = config.to_dict()
        
        assert data["time_slice"] == 45.0
        assert data["max_context_tokens"] == 64000
        assert "version" in data
    
    def test_config_validation(self):
        """Test configuration validation"""
        config = KernelConfig()
        
        # Valid values should not raise
        config.max_context_tokens = 1000
        config.time_slice = 1.0
        config.max_concurrent_agents = 1
        
        # Invalid values should raise ConfigError
        with pytest.raises(ConfigError):
            config.max_context_tokens = -100
        
        with pytest.raises(ConfigError):
            config.time_slice = 0
        
        with pytest.raises(ConfigError):
            config.max_concurrent_agents = 0


class TestConfigLoader:
    """Test ConfigLoader class"""
    
    def test_load_yaml_config(self):
        """Test loading YAML configuration file"""
        config_content = """
context:
  max_context_tokens: 64000
  
scheduler:
  time_slice: 30.0
  max_concurrent_agents: 5
  
storage:
  type: postgresql
  connection_string: postgresql://localhost:5432/test
  
metrics:
  enabled: true
  port: 9090
  
security:
  enabled: false
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write(config_content)
            f.flush()
            
            try:
                loader = ConfigLoader(f.name)
                config = loader.load()
                
                assert config.max_context_tokens == 64000
                assert config.time_slice == 30.0
                assert config.max_concurrent_agents == 5
                assert config.storage_type == "postgresql"
            finally:
                os.unlink(f.name)
    
    def test_load_json_config(self):
        """Test loading JSON configuration file"""
        config_content = """{
  "context": {
    "max_context_tokens": 32000
  },
  "scheduler": {
    "time_slice": 45.0
  }
}"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            f.write(config_content)
            f.flush()
            
            try:
                loader = ConfigLoader(f.name)
                config = loader.load()
                
                assert config.max_context_tokens == 32000
                assert config.time_slice == 45.0
            finally:
                os.unlink(f.name)
    
    def test_config_file_not_found(self):
        """Test handling of missing config file"""
        loader = ConfigLoader("/nonexistent/path/config.yaml")
        
        with pytest.raises(ConfigError):
            loader.load()
    
    def test_invalid_config_format(self):
        """Test handling of invalid config format"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write("invalid: yaml: content: [[[")
            f.flush()
            
            try:
                loader = ConfigLoader(f.name)
                
                with pytest.raises(ConfigError):
                    loader.load()
            finally:
                os.unlink(f.name)
    
    def test_config_merge(self):
        """Test merging base config with overrides"""
        base_config = KernelConfig.from_dict({
            "max_context_tokens": 128000,
            "time_slice": 60.0,
            "storage_type": "memory"
        })
        
        override_config = {
            "time_slice": 30.0,
            "storage_type": "postgresql"
        }
        
        merged = ConfigLoader.merge_configs(base_config, override_config)
        
        assert merged.max_context_tokens == 128000
        assert merged.time_slice == 30.0
        assert merged.storage_type == "postgresql"
    
    def test_get_nested_value(self):
        """Test getting nested configuration values"""
        config = KernelConfig()
        
        # Test getting nested values
        assert config.get_nested("context.max_context_tokens") == 128000
        assert config.get_nested("scheduler.time_slice") == 60.0
        
        # Test default for missing key
        assert config.get_nested("nonexistent.key", "default") == "default"
    
    def test_set_nested_value(self):
        """Test setting nested configuration values"""
        config = KernelConfig()
        
        config.set_nested("context.max_context_tokens", 64000)
        
        assert config.max_context_tokens == 64000


class TestEnvironmentConfigOverride:
    """Test EnvironmentConfigOverride class"""
    
    def test_env_override(self, monkeypatch):
        """Test environment variable overrides"""
        monkeypatch.setenv("AGENT_OS_MAX_CONTEXT_TOKENS", "64000")
        monkeypatch.setenv("AGENT_OS_TIME_SLICE", "45.0")
        monkeypatch.setenv("AGENT_OS_STORAGE_TYPE", "postgresql")
        
        config = KernelConfig()
        EnvironmentConfigOverride.apply(config)
        
        assert config.max_context_tokens == 64000
        assert config.time_slice == 45.0
        assert config.storage_type == "postgresql"
    
    def test_env_override_with_prefix(self, monkeypatch):
        """Test environment override with custom prefix"""
        monkeypatch.setenv("MY_APP_CONTEXT_TOKENS", "32000")
        
        override = EnvironmentConfigOverride(prefix="MY_APP_")
        config = KernelConfig()
        
        override.apply(config, key_mapping={
            "CONTEXT_TOKENS": ("max_context_tokens", int)
        })
        
        assert config.max_context_tokens == 32000
    
    def test_env_type_conversion(self, monkeypatch):
        """Test environment variable type conversion"""
        monkeypatch.setenv("AGENT_OS_TIME_SLICE", "not_a_number")
        
        config = KernelConfig()
        
        # Should not crash, should use default
        EnvironmentConfigOverride.apply(config)
    
    def test_sensitive_value_masking(self):
        """Test that sensitive values are masked"""
        override = EnvironmentConfigOverride()
        
        masked = override.mask_sensitive("postgresql://user:password@localhost/db")
        
        assert "password" not in masked
        assert masked == "postgresql://user:******@localhost/db"


class TestDefaultConfig:
    """Test default configuration values"""
    
    def test_default_context_config(self):
        """Test default context configuration"""
        assert DEFAULT_CONFIG["context"]["max_context_tokens"] == 128000
        assert DEFAULT_CONFIG["context"]["min_context_tokens"] == 1000
    
    def test_default_scheduler_config(self):
        """Test default scheduler configuration"""
        assert DEFAULT_CONFIG["scheduler"]["time_slice"] == 60.0
        assert DEFAULT_CONFIG["scheduler"]["max_concurrent_agents"] == 10
    
    def test_default_storage_config(self):
        """Test default storage configuration"""
        assert DEFAULT_CONFIG["storage"]["type"] == "memory"
    
    def test_default_metrics_config(self):
        """Test default metrics configuration"""
        assert DEFAULT_CONFIG["metrics"]["enabled"] is True
        assert DEFAULT_CONFIG["metrics"]["port"] == 9090
