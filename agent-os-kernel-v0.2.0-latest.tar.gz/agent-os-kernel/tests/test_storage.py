# -*- coding: utf-8 -*-
"""
Test Storage - PostgreSQL and Memory Storage

Tests for storage layer functionality.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
from typing import Dict, Any, List

from agent_os_kernel.core.storage import (
    StorageManager,
    StorageBackend,
    MemoryStorage,
    PostgreSQLStorage,
)


class TestMemoryStorage:
    """Tests for MemoryStorage backend"""
    
    def test_initialization(self):
        """Test memory storage initialization"""
        storage = MemoryStorage()
        
        assert storage.memories_db is not None
        assert storage.processes_db is not None
        assert storage.checkpoints_db is not None
        assert storage.context_pages_db is not None
        assert storage.audit_logs_db is not None
    
    def test_save_and_retrieve_memory(self):
        """Test saving and retrieving memories"""
        storage = MemoryStorage()
        
        # Save memory
        memory_id = storage.save_memory(
            agent_pid="agent-1",
            memory_type="fact",
            content="Python is a programming language",
            metadata={"source": "test"}
        )
        
        assert memory_id is not None
        
        # Retrieve memories
        memories = storage.retrieve_memories(agent_pid="agent-1")
        
        assert len(memories) == 1
        assert memories[0]['content'] == "Python is a programming language"
        assert memories[0]['memory_type'] == "fact"
    
    def test_retrieve_memories_by_type(self):
        """Test filtering memories by type"""
        storage = MemoryStorage()
        
        storage.save_memory("agent-1", "fact", "Fact 1")
        storage.save_memory("agent-1", "preference", "Preference 1")
        storage.save_memory("agent-1", "fact", "Fact 2")
        
        facts = storage.retrieve_memories("agent-1", memory_type="fact")
        
        assert len(facts) == 2
        for f in facts:
            assert f['memory_type'] == "fact"
    
    def test_save_and_load_process(self):
        """Test saving and loading process state"""
        storage = MemoryStorage()
        
        process_data = {
            'pid': 'process-1',
            'name': 'TestProcess',
            'state': 'running',
            'priority': 50
        }
        
        storage.save_process(process_data)
        loaded = storage.load_process('process-1')
        
        assert loaded is not None
        assert loaded['name'] == 'TestProcess'
    
    def test_save_and_load_checkpoint(self):
        """Test checkpoint save and load"""
        storage = MemoryStorage()
        
        checkpoint_id = storage.save_checkpoint(
            agent_pid="agent-1",
            process_state={'pid': 'agent-1', 'state': 'ready'},
            context_pages=[{'page_id': 'p1', 'content': 'test'}],
            description="Test checkpoint"
        )
        
        assert checkpoint_id is not None
        
        loaded = storage.load_checkpoint(checkpoint_id)
        
        assert loaded is not None
        assert loaded['description'] == "Test checkpoint"
        assert len(loaded['context_pages']) == 1
    
    def test_list_checkpoints(self):
        """Test listing checkpoints for an agent"""
        storage = MemoryStorage()
        
        storage.save_checkpoint("agent-1", {}, [], "Checkpoint 1")
        storage.save_checkpoint("agent-1", {}, [], "Checkpoint 2")
        storage.save_checkpoint("agent-2", {}, [], "Other checkpoint")
        
        checkpoints = storage.list_checkpoints("agent-1")
        
        assert len(checkpoints) == 2
    
    def test_save_and_load_context_page(self):
        """Test saving and loading context pages"""
        storage = MemoryStorage()
        
        page_data = {
            'page_id': 'page-1',
            'agent_pid': 'agent-1',
            'content': 'Test content',
            'tokens': 5,
            'importance_score': 0.8,
            'page_type': 'task'
        }
        
        page_id = storage.save_context_page(page_data)
        assert page_id == 'page-1'
        
        loaded = storage.load_context_page('page-1')
        assert loaded is not None
        assert loaded['content'] == 'Test content'
    
    def test_acquire_lock(self):
        """Test distributed lock acquisition"""
        storage = MemoryStorage()
        
        with storage.acquire_lock("test-lock") as acquired:
            assert acquired is True
        
        # Should be able to acquire again after release
        with storage.acquire_lock("test-lock") as acquired:
            assert acquired is True
    
    def test_task_queue(self):
        """Test task queue operations"""
        storage = MemoryStorage()
        
        task_id = storage.enqueue_task("queue-1", {"task": "test-task"})
        
        assert task_id is not None
        
        task = storage.dequeue_task("queue-1")
        
        assert task is not None
        assert task['data']['task'] == "test-task"
        assert task['status'] == "processing"
    
    def test_log_action(self):
        """Test audit logging"""
        storage = MemoryStorage()
        
        storage.log_action(
            agent_pid="agent-1",
            action_type="test_action",
            input_data={"input": "test"},
            output_data={"output": "result"},
            reasoning="Test reasoning"
        )
        
        logs = storage.get_audit_trail("agent-1")
        
        assert len(logs) == 1
        assert logs[0]['action_type'] == "test_action"
        assert logs[0]['reasoning'] == "Test reasoning"
    
    def test_replay_actions(self):
        """Test action replay"""
        storage = MemoryStorage()
        
        storage.log_action("agent-1", "action-1", {}, {}, "Reason 1")
        storage.log_action("agent-1", "action-2", {}, {}, "Reason 2")
        
        actions = storage.replay_actions("agent-1")
        
        assert len(actions) == 2
        assert actions[0]['action_type'] == "action-1"
    
    def test_close(self):
        """Test close method"""
        storage = MemoryStorage()
        # Should not raise
        storage.close()


class TestStorageManager:
    """Tests for StorageManager"""
    
    def test_default_backend(self):
        """Test that MemoryStorage is default backend"""
        manager = StorageManager()
        
        assert isinstance(manager.backend, MemoryStorage)
    
    def test_from_postgresql(self):
        """Test creating from PostgreSQL connection string"""
        with patch('agent_os_kernel.core.storage.PostgreSQLStorage') as mock_pg:
            mock_instance = MagicMock()
            mock_pg.return_value = mock_instance
            
            manager = StorageManager.from_postgresql("postgresql://localhost/test")
            
            mock_pg.assert_called_once_with("postgresql://localhost/test", enable_vector=True)
    
    def test_method_proxying(self):
        """Test that methods are properly proxied to backend"""
        manager = StorageManager()
        
        # These should work via __getattr__
        memory_id = manager.save_memory("agent-1", "test", "content")
        assert memory_id is not None
        
        memories = manager.retrieve_memories("agent-1")
        assert len(memories) == 1


class TestPostgreSQLStorage:
    """Tests for PostgreSQLStorage (mocked)"""
    
    @pytest.fixture
    def mock_pg_storage(self):
        """Create a mocked PostgreSQL storage"""
        with patch('agent_os_kernel.core.storage.psycopg2') as mock_psycopg2:
            mock_conn = MagicMock()
            mock_cursor = MagicMock()
            mock_psycopg2.connect.return_value = mock_conn
            mock_conn.cursor.return_value = mock_cursor
            
            # Mock pgvector
            mock_psycopg2.extras = MagicMock()
            
            storage = PostgreSQLStorage("postgresql://localhost/test")
            storage.conn = mock_conn
            storage.cur = mock_cursor
            
            yield storage
    
    def test_connection(self, mock_pg_storage):
        """Test PostgreSQL connection"""
        mock_pg_storage.cur.execute = MagicMock()
        mock_pg_storage.conn.commit = MagicMock()
        
        # Should not raise
        assert mock_pg_storage is not None
    
    def test_save_memory(self, mock_pg_storage):
        """Test saving memory to PostgreSQL"""
        mock_cursor = mock_pg_storage.cur
        mock_cursor.fetchone.return_value = ["memory-id-123"]
        mock_pg_storage.conn.commit = MagicMock()
        
        with patch.object(mock_pg_storage, 'enable_vector', False):
            memory_id = mock_pg_storage.save_memory(
                agent_pid="agent-1",
                memory_type="fact",
                content="Test content"
            )
        
        assert memory_id == "memory-id-123"
        mock_cursor.execute.assert_called()
    
    def test_save_checkpoint(self, mock_pg_storage):
        """Test saving checkpoint to PostgreSQL"""
        mock_pg_storage.conn.commit = MagicMock()
        
        checkpoint_id = mock_pg_storage.save_checkpoint(
            agent_pid="agent-1",
            process_state={"pid": "agent-1"},
            context_pages=[],
            description="Test"
        )
        
        assert checkpoint_id is not None
        mock_pg_storage.cur.execute.assert_called()
        mock_pg_storage.conn.commit.assert_called()
    
    def test_close(self, mock_pg_storage):
        """Test closing PostgreSQL connection"""
        mock_pg_storage.close()
        
        mock_pg_storage.cur.close.assert_called_once()
        mock_pg_storage.conn.close.assert_called_once()
