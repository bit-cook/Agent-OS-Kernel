# -*- coding: utf-8 -*-
"""
Tests for Metrics Module - Agent OS Kernel Test Suite
"""

import pytest
import time

from agent_os_kernel.core.metrics import (
    MetricsCollector,
    Metric,
    MetricsMiddleware,
    default_metrics
)


class TestMetric:
    """Test Metric dataclass"""
    
    def test_metric_creation(self):
        """Test creating a metric"""
        metric = Metric(
            name="test_counter",
            value=100.0,
            labels={"env": "test"},
            metric_type="counter"
        )
        
        assert metric.name == "test_counter"
        assert metric.value == 100.0
        assert metric.labels["env"] == "test"
        assert metric.metric_type == "counter"
    
    def test_metric_timestamp(self):
        """Test metric timestamp is set automatically"""
        before = time.time()
        metric = Metric(name="test", value=1.0)
        after = time.time()
        
        assert before <= metric.timestamp <= after


class TestMetricsCollector:
    """Test MetricsCollector class"""
    
    def test_initialization(self):
        """Test collector initialization"""
        collector = MetricsCollector(prefix="test")
        
        assert collector.prefix == "test"
        assert collector.counters == {}
        assert collector.gauges == {}
        assert collector.histograms == {}
    
    def test_increment_counter(self):
        """Test counter increment"""
        collector = MetricsCollector()
        
        collector.increment_counter("requests", 5)
        collector.increment_counter("requests", 3)
        
        assert collector.get_counter("requests") == 8.0
    
    def test_set_gauge(self):
        """Test gauge setter"""
        collector = MetricsCollector()
        
        collector.set_gauge("cpu_usage", 45.5)
        
        assert collector.get_gauge("cpu_usage") == 45.5
    
    def test_gauge_increment_decrement(self):
        """Test gauge increment and decrement"""
        collector = MetricsCollector()
        
        collector.set_gauge("queue_depth", 10)
        collector.gauge_increment("queue_depth", 5)
        collector.gauge_decrement("queue_depth", 3)
        
        assert collector.get_gauge("queue_depth") == 12
    
    def test_observe_histogram(self):
        """Test histogram observation"""
        collector = MetricsCollector()
        
        for i in [10, 20, 30, 40, 50]:
            collector.observe_histogram("latency", i)
        
        # Check percentile calculation
        p50 = collector.get_histogram_percentile("latency", 0.5)
        p90 = collector.get_histogram_percentile("latency", 0.9)
        
        assert p50 == 30  # 50th percentile should be ~30
        assert p90 == 50  # 90th percentile should be ~50
    
    def test_record_token_usage(self):
        """Test token usage recording"""
        collector = MetricsCollector()
        
        collector.record_token_usage(1000, 500)
        
        assert collector.get_counter("tokens_input_total") == 1000.0
        assert collector.get_counter("tokens_output_total") == 500.0
        assert collector.get_gauge("tokens_input_last") == 1000.0
        assert collector.get_gauge("tokens_output_last") == 500.0
    
    def test_record_api_call(self):
        """Test API call recording"""
        collector = MetricsCollector()
        
        collector.record_api_call("openai", 150.0, success=True)
        collector.record_api_call("openai", 200.0, success=False)
        
        assert collector.get_counter("api_calls_total") == 2.0
        assert collector.get_counter("api_calls_errors_total") == 1.0
    
    def test_record_agent_events(self):
        """Test agent lifecycle event recording"""
        collector = MetricsCollector()
        
        collector.record_agent_created("agent-1")
        collector.record_agent_created("agent-2")
        collector.record_agent_terminated("agent-1", reason="completed")
        
        assert collector.get_counter("agents_created_total") == 2.0
        assert collector.get_counter("agents_terminated_total") == 1.0
        assert collector.get_gauge("agents_active") == 1
    
    def test_record_context_cache(self):
        """Test context cache hit recording"""
        collector = MetricsCollector()
        
        collector.record_context_cache_hit(True)
        collector.record_context_cache_hit(True)
        collector.record_context_cache_hit(False)
        
        assert collector.get_counter("context_cache_hits_total") == 2.0
        assert collector.get_counter("context_cache_misses_total") == 1.0
    
    def test_record_tool_call(self):
        """Test tool call recording"""
        collector = MetricsCollector()
        
        collector.record_tool_call("calculator", 50.0, success=True)
        collector.record_tool_call("calculator", 100.0, success=False)
        
        assert collector.get_counter("tool_calls_total") == 2.0
        assert collector.get_counter("tool_calls_errors_total") == 1.0
    
    def test_record_checkpoint(self):
        """Test checkpoint recording"""
        collector = MetricsCollector()
        
        collector.record_checkpoint_created()
        collector.record_checkpoint_created()
        collector.record_checkpoint_restored()
        
        assert collector.get_counter("checkpoints_created_total") == 2.0
        assert collector.get_counter("checkpoints_restored_total") == 1.0
        assert collector.get_gauge("checkpoints_active") == 1
    
    def test_record_queue_depth(self):
        """Test queue depth recording"""
        collector = MetricsCollector()
        
        collector.record_queue_depth("input", 100)
        collector.record_queue_depth("output", 50)
        
        assert collector.get_gauge("queue_input_depth") == 100
        assert collector.get_gauge("queue_output_depth") == 50
    
    def test_to_prometheus_format(self):
        """Test Prometheus format export"""
        collector = MetricsCollector()
        collector.set_gauge("cpu_usage", 75.5)
        collector.increment_counter("requests", 100)
        collector.observe_histogram("latency", 100)
        
        output = collector.to_prometheus()
        
        assert "cpu_usage" in output
        assert "requests_total" in output
        assert "latency" in output
        assert "75.50" in output
        assert "# HELP" in output
        assert "# TYPE" in output
    
    def test_to_json_format(self):
        """Test JSON format export"""
        collector = MetricsCollector()
        collector.set_gauge("cpu_usage", 50.0)
        collector.increment_counter("requests", 10)
        
        output = collector.to_json()
        
        assert "timestamp" in output
        assert "uptime_seconds" in output
        assert "counters" in output
        assert "gauges" in output
        assert output["gauges"]["cpu_usage"] == 50.0
        assert output["counters"]["requests_total"] == 10.0
    
    def test_reset(self):
        """Test metrics reset"""
        collector = MetricsCollector()
        
        collector.set_gauge("cpu_usage", 100.0)
        collector.increment_counter("requests", 1000)
        collector.observe_histogram("latency", 500)
        
        collector.reset()
        
        assert collector.get_gauge("cpu_usage") == 0.0
        assert collector.get_counter("requests") == 0.0
        assert collector.get_histogram_percentile("latency", 0.5) == 0.0
    
    def test_thread_safety(self):
        """Test thread-safe operations"""
        import threading
        
        collector = MetricsCollector()
        
        def increment_many():
            for _ in range(100):
                collector.increment_counter("thread_test", 1)
        
        threads = [threading.Thread(target=increment_many) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        
        # Should have exactly 1000 increments
        assert collector.get_counter("thread_test") == 1000.0


class TestDefaultMetrics:
    """Test default metrics instance"""
    
    def test_default_metrics_exists(self):
        """Test default metrics collector exists"""
        assert default_metrics is not None
        assert isinstance(default_metrics, MetricsCollector)
    
    def test_get_metrics_function(self):
        """Test get_metrics convenience function"""
        from agent_os_kernel.core.metrics import get_metrics
        
        metrics = get_metrics()
        
        assert metrics is default_metrics


class TestMetricsMiddleware:
    """Test MetricsMiddleware for WSGI"""
    
    def test_middleware_init(self):
        """Test middleware initialization"""
        collector = MetricsCollector()
        middleware = MetricsMiddleware(app=None, metrics=collector)
        
        assert middleware.metrics == collector
        assert middleware.path == "/metrics"
    
    def test_metrics_endpoint(self):
        """Test /metrics endpoint"""
        collector = MetricsCollector()
        collector.set_gauge("test_metric", 42.0)
        
        # Create mock app
        mock_app = Mock()
        
        middleware = MetricsMiddleware(app=mock_app, metrics=collector, path="/metrics")
        
        # Simulate request to /metrics
        environ = {'PATH_INFO': '/metrics'}
        response_started = []
        result = middleware(environ, lambda status, headers: response_started.append((status, headers)))
        
        output = b''.join(result)
        
        assert b"test_metric" in output
        assert b"42" in output


class MockApp:
    """Mock WSGI app for testing"""
    
    def __call__(self, environ, start_response):
        self.environ = environ
        response_started = []
        start_response('200 OK', [('Content-Type', 'text/plain')])
        return [b'OK']


class Mock:
    """Simple mock class"""
    pass
