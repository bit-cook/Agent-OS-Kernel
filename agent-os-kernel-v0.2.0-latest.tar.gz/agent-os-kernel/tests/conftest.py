# -*- coding: utf-8 -*-
"""
Test Fixtures and Mocks - Agent OS Kernel Test Suite

Reusable fixtures and mock objects for testing.
"""

import pytest
from typing import Dict, Any, List, Optional
from unittest.mock import Mock, MagicMock, patch
from dataclasses import dataclass

from agent_os_kernel.core.types import (
    AgentProcess, AgentState, ContextPage, PageStatus,
    Checkpoint, ResourceQuota
)


@pytest.fixture
def mock_storage_backend():
    """Create a mock storage backend"""
    storage = Mock()
    storage.save_memory = Mock(return_value="memory-123")
    storage.retrieve_memories = Mock(return_value=[])
    storage.save_process = Mock()
    storage.load_process = Mock(return_value=None)
    storage.save_checkpoint = Mock(return_value="checkpoint-123")
    storage.load_checkpoint = Mock(return_value=None)
    storage.save_context_page = Mock(return_value="page-123")
    storage.load_context_page = Mock(return_value=None)
    storage.log_action = Mock()
    storage.close = Mock()
    return storage


@pytest.fixture
def sample_agent_process():
    """Create a sample agent process"""
    return AgentProcess(
        pid="test-agent-001",
        name="TestAgent",
        state=AgentState.READY,
        priority=50,
        context={"task": "Test task"}
    )


@pytest.fixture
def sample_context_page():
    """Create a sample context page"""
    return ContextPage(
        page_id="test-page-001",
        agent_pid="test-agent-001",
        content="This is test content for the context page",
        tokens=10,
        importance_score=0.8,
        page_type="task"
    )


@pytest.fixture
def sample_checkpoint():
    """Create a sample checkpoint"""
    return Checkpoint(
        checkpoint_id="test-checkpoint-001",
        agent_pid="test-agent-001",
        process_state={"pid": "test-agent-001", "name": "TestAgent"},
        context_pages=[]
    )


@pytest.fixture
def sample_resource_quota():
    """Create a sample resource quota"""
    return ResourceQuota(
        max_tokens_per_window=100000,
        max_api_calls_per_window=1000,
        max_tokens_per_request=10000,
        window_seconds=3600
    )


@pytest.fixture
def mock_kernel_config():
    """Create mock kernel configuration"""
    config = Mock()
    config.max_context_tokens = 128000
    config.time_slice = 60.0
    config.enable_sandbox = False
    return config


class MockLLMResponse:
    """Mock LLM response for testing"""
    
    def __init__(self, 
                 content: str = "Test response",
                 model: str = "test-model",
                 usage: Optional[Dict[str, int]] = None):
        self.content = content
        self.model = model
        self.usage = usage or {'prompt_tokens': 10, 'completion_tokens': 20, 'total_tokens': 30}
        self.finish_reason = "stop"
    
    def __str__(self) -> str:
        return f"MockLLMResponse(content={self.content!r}, tokens={self.usage.get('total_tokens', 0)})"


class MockToolResult:
    """Mock tool result for testing"""
    
    def __init__(self,
                 success: bool = True,
                 data: Any = None,
                 error: Optional[str] = None,
                 error_code: int = 200):
        self.success = success
        self.data = data
        self.error = error
        self.error_code = error_code
        self.metadata = {"duration_ms": 100}
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "data": self.data,
            "error": self.error,
            "error_code": self.error_code,
            "metadata": self.metadata
        }


class MockContextManager:
    """Mock context manager for testing"""
    
    def __init__(self, max_tokens: int = 128000):
        self.max_context_tokens = max_tokens
        self.current_usage = 0
        self.pages: Dict[str, ContextPage] = {}
        self.agent_pages: Dict[str, List[str]] = {}
    
    def allocate_page(self, agent_pid: str, content: str, 
                     importance: float = 0.5, page_type: str = "general") -> str:
        page_id = f"page-{len(self.pages)}"
        page = ContextPage(
            page_id=page_id,
            agent_pid=agent_pid,
            content=content,
            tokens=len(content.split()),
            importance_score=importance,
            page_type=page_type
        )
        self.pages[page_id] = page
        self.agent_pages.setdefault(agent_pid, []).append(page_id)
        self.current_usage += page.tokens
        return page_id
    
    def access_page(self, page_id: str) -> Optional[ContextPage]:
        return self.pages.get(page_id)
    
    def get_agent_context(self, agent_pid: str) -> str:
        page_ids = self.agent_pages.get(agent_pid, [])
        pages = [self.pages[pid] for pid in page_ids if pid in self.pages]
        return "\n\n".join(p.content for p in pages)
    
    def release_agent_pages(self, agent_pid: str) -> int:
        page_ids = self.agent_pages.get(agent_pid, [])
        for pid in page_ids:
            if pid in self.pages:
                del self.pages[pid]
        count = len(page_ids)
        del self.agent_pages[agent_pid]
        return count


class MockScheduler:
    """Mock scheduler for testing"""
    
    def __init__(self):
        self.processes: Dict[str, AgentProcess] = {}
        self.ready_queue: List[AgentProcess] = []
        self.running: Optional[AgentProcess] = None
    
    def add_process(self, process: AgentProcess):
        self.processes[process.pid] = process
        self.ready_queue.append(process)
    
    def schedule(self) -> Optional[AgentProcess]:
        if self.ready_queue:
            self.running = self.ready_queue.pop(0)
            return self.running
        return None
    
    def terminate_process(self, pid: str, reason: str = "completed"):
        if pid in self.processes:
            self.processes[pid].state = AgentState.TERMINATED
        if self.running and self.running.pid == pid:
            self.running = None


class MockTool:
    """Mock tool for testing"""
    
    def __init__(self, name: str = "mock_tool", description: str = "A mock tool"):
        self._name = name
        self._description = description
        self.call_count = 0
        self.last_params = {}
    
    def name(self) -> str:
        return self._name
    
    def description(self) -> str:
        return self._description
    
    def parameters(self) -> List:
        return []
    
    def execute(self, **kwargs) -> MockToolResult:
        self.call_count += 1
        self.last_params = kwargs
        return MockToolResult(success=True, data={"result": "success"})
    
    def get_schema(self) -> Dict[str, Any]:
        return {
            "name": self.name(),
            "description": self.description(),
            "parameters": {
                "type": "object",
                "properties": {},
                "required": []
            }
        }


@pytest.fixture
def mock_llm_client():
    """Create a mock LLM client"""
    client = Mock()
    client.complete = Mock(return_value=MockLLMResponse())
    client.stream_complete = Mock(return_value=iter([
        MockLLMResponse(content="Part "),
        MockLLMResponse(content="2 "),
        MockLLMResponse(content="3"),
    ]))
    client.get_model_info = Mock(return_value={"name": "test-model", "max_tokens": 128000})
    return client


@pytest.fixture
def temp_config_file(tmp_path):
    """Create a temporary config file"""
    config_content = """
database:
  connection_string: postgresql://localhost:5432/test
  pool_size: 5
  enable_vector: false

context:
  max_context_tokens: 64000
  enable_semantic_importance: false

scheduler:
  time_slice: 30.0
  max_concurrent_agents: 5

logging:
  level: DEBUG
  enable_audit: false
"""
    config_file = tmp_path / "test-config.yaml"
    config_file.write_text(config_content)
    return str(config_file)


@pytest.fixture
def cleanup_checkpoints():
    """Fixture to track checkpoints for cleanup"""
    checkpoints = []
    yield checkpoints
    # Cleanup would happen here if needed
