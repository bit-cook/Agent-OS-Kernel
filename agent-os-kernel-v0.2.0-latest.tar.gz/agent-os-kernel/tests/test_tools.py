# -*- coding: utf-8 -*-
"""
Test Tools - Tool Registry and Tool System

Tests for the tool calling system.
"""

import pytest
import json
from unittest.mock import Mock, patch, MagicMock
from typing import Dict, Any, List

from agent_os_kernel.tools.base import (
    Tool,
    SimpleTool,
    CLITool,
    ToolRegistry,
    ToolResult,
    ToolParameter,
    ToolErrorCode,
)


class TestToolParameter:
    """Tests for ToolParameter"""
    
    def test_to_dict(self):
        """Test parameter to dictionary conversion"""
        param = ToolParameter(
            name="query",
            type="string",
            description="Search query",
            required=True
        )
        
        result = param.to_dict()
        
        assert result['name'] == "query"
        assert result['type'] == "string"
        assert result['required'] is True
        assert result['description'] == "Search query"
    
    def test_with_default(self):
        """Test parameter with default value"""
        param = ToolParameter(
            name="limit",
            type="integer",
            description="Max results",
            required=False,
            default=10
        )
        
        result = param.to_dict()
        
        assert result['default'] == 10
        assert result['required'] is False
    
    def test_with_enum(self):
        """Test parameter with enum values"""
        param = ToolParameter(
            name="status",
            type="string",
            description="Task status",
            enum=["pending", "running", "completed"]
        )
        
        result = param.to_dict()
        
        assert result['enum'] == ["pending", "running", "completed"]


class TestToolResult:
    """Tests for ToolResult"""
    
    def test_success_result(self):
        """Test creating a success result"""
        result = ToolResult.success(data={"answer": 42})
        
        assert result.success is True
        assert result.data == {"answer": 42}
        assert result.error is None
        assert result.error_code == ToolErrorCode.SUCCESS
    
    def test_error_result(self):
        """Test creating an error result"""
        result = ToolResult.error(
            message="File not found",
            code=ToolErrorCode.NOT_FOUND
        )
        
        assert result.success is False
        assert result.error == "File not found"
        assert result.error_code == ToolErrorCode.NOT_FOUND
    
    def test_to_dict(self):
        """Test converting result to dictionary"""
        result = ToolResult.success(data={"key": "value"})
        
        data = result.to_dict()
        
        assert data['success'] is True
        assert data['data'] == {"key": "value"}
        assert data['error_code'] == 200
    
    def test_to_json(self):
        """Test converting result to JSON string"""
        result = ToolResult.success(data={"count": 5})
        
        json_str = result.to_json()
        
        parsed = json.loads(json_str)
        assert parsed['success'] is True
        assert parsed['data']['count'] == 5


class TestSimpleTool:
    """Tests for SimpleTool"""
    
    def test_basic_tool(self):
        """Test creating a basic simple tool"""
        def add_numbers(a: int, b: int) -> int:
            return a + b
        
        tool = SimpleTool(
            name="add",
            description="Add two numbers",
            func=add_numbers
        )
        
        assert tool.name() == "add"
        assert tool.description() == "Add two numbers"
    
    def test_execute_tool(self):
        """Test executing a simple tool"""
        def greet(name: str) -> str:
            return f"Hello, {name}!"
        
        tool = SimpleTool(
            name="greet",
            description="Greet someone",
            func=greet
        )
        
        result = tool.execute(name="World")
        
        assert result.success is True
        assert result.data == "Hello, World!"
    
    def test_execute_with_error(self):
        """Test tool execution with error"""
        def risky_operation():
            raise ValueError("Something went wrong")
        
        tool = SimpleTool(
            name="risky",
            description="Risky operation",
            func=risky_operation
        )
        
        result = tool.execute()
        
        assert result.success is False
        assert "Something went wrong" in result.error


class TestCLITool:
    """Tests for CLITool"""
    
    def test_basic_cli_tool(self):
        """Test creating a basic CLI tool"""
        tool = CLITool(
            command="echo",
            tool_name="echo",
            description="Echo input",
            timeout=5
        )
        
        assert tool.name() == "echo"
        assert tool.command == "echo"
    
    def test_execute_with_params(self):
        """Test CLI tool execution with parameters"""
        tool = CLITool(
            command="echo",
            tool_name="echo",
            description="Echo input"
        )
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = Mock(
                returncode=0,
                stdout='{"result": "success"}',
                stderr=''
            )
            
            result = tool.execute(message="test")
            
            # Command should be built with parameters
            mock_run.assert_called()
            args, kwargs = mock_run.call_args
            assert "echo" in args[0]
    
    def test_execute_json_output(self):
        """Test CLI tool with JSON output"""
        tool = CLITool(
            command="jq",
            tool_name="jq",
            description="Process JSON"
        )
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = Mock(
                returncode=0,
                stdout='{"key": "value"}',
                stderr=''
            )
            
            result = tool.execute(filter=".key")
            
            assert result.success is True
            assert result.data['key'] == "value"
    
    def test_execute_with_error(self):
        """Test CLI tool with error response"""
        tool = CLITool(
            command="ls",
            tool_name="ls",
            description="List files"
        )
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = Mock(
                returncode=1,
                stdout='',
                stderr="No such file"
            )
            
            result = tool.execute(path="/nonexistent")
            
            assert result.success is False
            assert result.error_code == ToolErrorCode.INTERNAL_ERROR
    
    def test_exit_code_mapping(self):
        """Test exit code to error code mapping"""
        tool = CLITool(
            command="test",
            tool_name="test",
            description="Test"
        )
        
        # Test various exit codes
        assert tool._map_exit_code(0) == ToolErrorCode.SUCCESS
        assert tool._map_exit_code(1) == ToolErrorCode.INTERNAL_ERROR
        assert tool._map_exit_code(2) == ToolErrorCode.BAD_REQUEST
        assert tool._map_exit_code(127) == ToolErrorCode.NOT_FOUND
        assert tool._map_exit_code(999) == ToolErrorCode.INTERNAL_ERROR


class TestToolRegistry:
    """Tests for ToolRegistry"""
    
    def test_registration(self):
        """Test registering a tool"""
        registry = ToolRegistry()
        
        tool = MockTool(name="test_tool", description="A test tool")
        registry.register(tool, category="test")
        
        assert registry.get("test_tool") is tool
        assert "test" in registry.categories
    
    def test_get_nonexistent_tool(self):
        """Test getting a tool that doesn't exist"""
        registry = ToolRegistry()
        
        result = registry.get("nonexistent")
        
        assert result is None
    
    def test_list_all_tools(self):
        """Test listing all registered tools"""
        registry = ToolRegistry()
        
        registry.register(MockTool("tool1", "Description 1"), "category1")
        registry.register(MockTool("tool2", "Description 2"), "category2")
        
        tools = registry.list_tools()
        
        assert len(tools) == 2
    
    def test_list_by_category(self):
        """Test listing tools by category"""
        registry = ToolRegistry()
        
        registry.register(MockTool("tool1", "Desc 1"), "utilities")
        registry.register(MockTool("tool2", "Desc 2"), "utilities")
        registry.register(MockTool("tool3", "Desc 3"), "data")
        
        tools = registry.list_tools(category="utilities")
        
        assert len(tools) == 2
    
    def test_search_tools(self):
        """Test searching tools by keyword"""
        registry = ToolRegistry()
        
        registry.register(MockTool("file_read", "Read files from disk"))
        registry.register(MockTool("file_write", "Write files to disk"))
        registry.register(MockTool("calculator", "Perform calculations"))
        
        results = registry.search_tools("file")
        
        assert len(results) == 2
    
    def test_get_tool_schemas(self):
        """Test getting tool schemas for LLM"""
        registry = ToolRegistry()
        
        registry.register(MockTool("test", "Test tool"))
        
        schemas = registry.get_tool_schemas()
        
        assert len(schemas) == 1
        assert schemas[0]['name'] == "test"
        assert 'parameters' in schemas[0]
    
    def test_check_command_exists(self):
        """Test checking if command exists"""
        registry = ToolRegistry()
        
        # These should exist on most systems
        assert registry._check_command_exists("python") is True
        assert registry._check_command_exists("nonexistent-command-xyz123") is False
    
    def test_auto_discover_cli_tools(self):
        """Test automatic CLI tool discovery"""
        registry = ToolRegistry()
        
        registry.auto_discover_cli_tools()
        
        # At least some common tools should be discovered
        # (depends on what's installed on the system)


class TestAbstractTool:
    """Tests for abstract Tool class"""
    
    def test_abstract_execute_raises(self):
        """Test that abstract execute raises NotImplemented"""
        class IncompleteTool(Tool):
            def name(self) -> str:
                return "incomplete"
            
            def description(self) -> str:
                return "Incomplete tool"
            
            def execute(self, **kwargs):
                # Must be implemented
                pass
        
        tool = IncompleteTool()
        
        # Abstract method should be implemented
        # This tests that our pattern works
        assert tool.name() == "incomplete"
    
    def test_validate_params_valid(self):
        """Test parameter validation with valid params"""
        class TestTool(Tool):
            def name(self) -> str:
                return "test"
            
            def description(self) -> str:
                return "Test"
            
            def parameters(self) -> List[ToolParameter]:
                return [
                    ToolParameter("required_param", "string", "Required", required=True),
                    ToolParameter("optional_param", "integer", "Optional", required=False, default=10)
                ]
            
            def execute(self, **kwargs):
                return ToolResult.success()
        
        tool = TestTool()
        valid, error = tool.validate_params(required_param="value")
        
        assert valid is True
        assert error == ""
    
    def test_validate_params_missing_required(self):
        """Test parameter validation with missing required param"""
        class TestTool(Tool):
            def name(self) -> str:
                return "test"
            
            def description(self) -> str:
                return "Test"
            
            def parameters(self) -> List[ToolParameter]:
                return [
                    ToolParameter("required_param", "string", "Required", required=True)
                ]
            
            def execute(self, **kwargs):
                return ToolResult.success()
        
        tool = TestTool()
        valid, error = tool.validate_params()
        
        assert valid is False
        assert "required_param" in error
    
    def test_validate_params_unknown(self):
        """Test parameter validation with unknown param"""
        class TestTool(Tool):
            def name(self) -> str:
                return "test"
            
            def description(self) -> str:
                return "Test"
            
            def parameters(self) -> List[ToolParameter]:
                return []
            
            def execute(self, **kwargs):
                return ToolResult.success()
        
        tool = TestTool()
        valid, error = tool.validate_params(unknown_param="value")
        
        assert valid is False
        assert "Unknown parameter" in error
    
    def test_get_schema(self):
        """Test getting tool schema"""
        class TestTool(Tool):
            def name(self) -> str:
                return "test"
            
            def description(self) -> str:
                return "A test tool"
            
            def parameters(self) -> List[ToolParameter]:
                return [
                    ToolParameter("param1", "string", "Param 1", required=True)
                ]
            
            def execute(self, **kwargs):
                return ToolResult.success()
        
        tool = TestTool()
        schema = tool.get_schema()
        
        assert schema['name'] == "test"
        assert schema['parameters']['required'] == ['param1']
