# -*- coding: utf-8 -*-
"""
Performance Benchmarks - Agent-OS-Kernel 性能基准测试
"""

import time
import statistics
from typing import Dict, List, Any
from agent_os_kernel import AgentOSKernel
from agent_os_kernel.core.metrics import MetricsCollector


class PerformanceBenchmark:
    """性能基准测试类"""
    
    def __init__(self, iterations: int = 100):
        self.iterations = iterations
        self.results: Dict[str, Dict] = {}
    
    def benchmark_kernel_init(self) -> Dict[str, float]:
        """内核初始化基准测试"""
        times = []
        
        for _ in range(self.iterations):
            start = time.perf_counter()
            kernel = AgentOSKernel()
            end = time.perf_counter()
            times.append((end - start) * 1000)  # 转换为毫秒
        
        return self._calculate_stats(times)
    
    def benchmark_spawn_agent(self, kernel: AgentOSKernel) -> Dict[str, float]:
        """Agent 创建基准测试"""
        times = []
        
        for i in range(self.iterations):
            start = time.perf_counter()
            pid = kernel.spawn_agent(f"BenchmarkAgent-{i}", "Test task")
            end = time.perf_counter()
            times.append((end - start) * 1000)
        
        return self._calculate_stats(times)
    
    def benchmark_checkpoints(self, kernel: AgentOSKernel) -> Dict[str, float]:
        """检查点基准测试"""
        # 先创建 agent
        pid = kernel.spawn_agent("CheckpointAgent", "Test for checkpoints")
        
        create_times = []
        restore_times = []
        
        for _ in range(min(20, self.iterations)):  # 限制数量
            # 创建检查点
            start = time.perf_counter()
            cp_id = kernel.create_checkpoint(pid, "Benchmark checkpoint")
            end = time.perf_counter()
            create_times.append((end - start) * 1000)
            
            # 恢复检查点
            start = time.perf_counter()
            new_pid = kernel.restore_checkpoint(cp_id)
            end = time.perf_counter()
            restore_times.append((end - start) * 1000)
        
        return {
            "create": self._calculate_stats(create_times),
            "restore": self._calculate_stats(restore_times)
        }
    
    def benchmark_metrics(self, metrics: MetricsCollector) -> Dict[str, float]:
        """指标收集基准测试"""
        times = []
        
        for _ in range(self.iterations):
            start = time.perf_counter()
            metrics.record_api_call("test", 100.0, True)
            metrics.record_token_usage(500, 250)
            end = time.perf_counter()
            times.append((end - start) * 1000)
        
        return self._calculate_stats(times)
    
    def benchmark_token_estimation(self) -> Dict[str, float]:
        """Token 估算基准测试"""
        from agent_os_kernel.utils import estimate_tokens
        
        texts = [
            "Short text",
            "This is a medium length sentence with several words",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. " * 10,
            "中文测试文本，包含英文和中文混合内容。" * 20,
        ]
        
        results = {}
        for i, text in enumerate(texts):
            times = []
            for _ in range(self.iterations // 10):
                start = time.perf_counter()
                estimate_tokens(text)
                end = time.perf_counter()
                times.append((end - start) * 1000)
            results[f"text_len_{len(text)}"] = self._calculate_stats(times)
        
        return results
    
    def _calculate_stats(self, values: List[float]) -> Dict[str, float]:
        """计算统计数据"""
        if not values:
            return {"min": 0, "max": 0, "mean": 0, "median": 0, "p95": 0, "p99": 0}
        
        sorted_values = sorted(values)
        n = len(values)
        
        return {
            "min": min(values),
            "max": max(values),
            "mean": statistics.mean(values),
            "median": statistics.median(values),
            "p95": sorted_values[int(n * 0.95)],
            "p99": sorted_values[int(n * 0.99)] if n > 1 else max(values),
            "std_dev": statistics.stdev(values) if n > 1 else 0,
            "iterations": n
        }
    
    def run_full_benchmark(self) -> Dict[str, Any]:
        """运行完整基准测试"""
        print("\n" + "=" * 60)
        print("Agent-OS-Kernel 性能基准测试")
        print("=" * 60)
        print(f"迭代次数: {self.iterations}")
        print()
        
        results = {}
        
        # 1. 内核初始化
        print("🔄 测试 1: 内核初始化...")
        results["kernel_init"] = self.benchmark_kernel_init()
        self._print_results("   ", results["kernel_init"])
        
        # 2. Agent 创建
        print("\n🔄 测试 2: Agent 创建...")
        kernel = AgentOSKernel()
        results["spawn_agent"] = self.benchmark_spawn_agent(kernel)
        self._print_results("   ", results["spawn_agent"])
        
        # 3. 检查点操作
        print("\n🔄 测试 3: 检查点操作...")
        results["checkpoints"] = self.benchmark_checkpoints(kernel)
        print("   创建: " + self._format_stats(results["checkpoints"]["create"]))
        print("   恢复: " + self._format_stats(results["checkpoints"]["restore"]))
        
        # 4. 指标收集
        print("\n🔄 测试 4: 指标收集...")
        metrics = MetricsCollector()
        results["metrics"] = self.benchmark_metrics(metrics)
        self._print_results("   ", results["metrics"])
        
        # 5. Token 估算
        print("\n🔄 测试 5: Token 估算...")
        results["token_estimation"] = self.benchmark_token_estimation()
        for key, stats in results["token_estimation"].items():
            print(f"   {key}: mean={stats['mean']:.4f}ms")
        
        # 汇总
        print("\n" + "=" * 60)
        print("📊 基准测试汇总")
        print("=" * 60)
        
        # 计算总体评分
        scores = []
        
        # 初始化速度评分 (越快越好)
        init_score = max(0, 100 - results["kernel_init"]["mean"] * 10)
        scores.append(("初始化", init_score))
        
        # Agent 创建评分
        spawn_score = max(0, 100 - results["spawn_agent"]["mean"] * 100)
        scores.append(("Agent创建", spawn_score))
        
        # 检查点评分
        cp_score = max(0, 100 - (results["checkpoints"]["create"]["mean"] + 
                                   results["checkpoints"]["restore"]["mean"]) * 5)
        scores.append(("检查点", cp_score))
        
        # 指标评分
        metrics_score = max(0, 100 - results["metrics"]["mean"] * 1000)
        scores.append(("指标收集", metrics_score))
        
        for name, score in scores:
            bar = "█" * int(score / 10) + "░" * (10 - int(score / 10))
            print(f"   {name:8s}: [{bar}] {score:.1f}/100")
        
        overall = sum(s for _, s in scores) / len(scores)
        print(f"\n   {'总体评分':8s}: [{'█' * int(overall/10)}{'░' * (10 - int(overall/10))}] {overall:.1f}/100")
        
        print("\n✅ 基准测试完成!")
        
        return results
    
    def _print_results(self, prefix: str, stats: Dict[str, float]):
        """打印统计结果"""
        print(f"{prefix}平均: {stats['mean']:.4f}ms | "
              f"中位数: {stats['median']:.4f}ms | "
              f"P95: {stats['p95']:.4f}ms")
    
    def _format_stats(self, stats: Dict[str, float]) -> str:
        """格式化统计"""
        return f"mean={stats['mean']:.2f}ms, p95={stats['p95']:.2f}ms"


def run_quick_benchmark():
    """快速基准测试"""
    print("\n" + "=" * 60)
    print("⚡ 快速基准测试")
    print("=" * 60)
    
    bench = PerformanceBenchmark(iterations=50)
    
    # 快速测试
    print("\n🔄 内核初始化...")
    stats = bench.benchmark_kernel_init()
    print(f"   平均: {stats['mean']:.2f}ms | P95: {stats['p95']:.2f}ms")
    
    print("\n🔄 Agent 创建...")
    kernel = AgentOSKernel()
    stats = bench.benchmark_spawn_agent(kernel)
    print(f"   平均: {stats['mean']:.4f}ms | P95: {stats['p95']:.4f}ms")
    
    print("\n🔄 Token 估算...")
    from agent_os_kernel.utils import estimate_tokens
    start = time.perf_counter()
    for _ in range(1000):
        estimate_tokens("Test text for token estimation")
    elapsed = (time.perf_counter() - start) * 1000
    print(f"   1000次估算: {elapsed:.2f}ms | 每次: {elapsed/1000:.4f}ms")
    
    print("\n✅ 快速测试完成!")


if __name__ == "__main__":
    import sys
    
    if "--quick" in sys.argv:
        run_quick_benchmark()
    else:
        bench = PerformanceBenchmark(iterations=100)
        results = bench.run_full_benchmark()
