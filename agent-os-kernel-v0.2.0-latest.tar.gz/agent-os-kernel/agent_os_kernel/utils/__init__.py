# -*- coding: utf-8 -*-
"""
Utilities - Common utilities for Agent OS Kernel
"""

import re
import json
import hashlib
import uuid
import time
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime


# ========== Token Estimation ==========

def estimate_tokens(text: str) -> int:
    """
    Estimate token count for text
    
    Uses simple word-based estimation with refinement for common patterns.
    For production, use tiktoken or similar.
    
    Args:
        text: Input text
        
    Returns:
        Estimated token count
    """
    if not text:
        return 0
    
    # More accurate estimation
    # Average English word is ~1.3 tokens
    # Average Chinese character is ~0.5 tokens
    
    english_words = len(re.findall(r'\b[a-zA-Z]+\b', text))
    chinese_chars = len(re.findall(r'[\u4e00-\u9fff]', text))
    other_chars = len(text) - english_words * 4 - chinese_chars * 2
    
    # Estimate
    tokens = (english_words * 1.3 + 
              chinese_chars * 0.5 + 
              other_chars * 0.25)
    
    return int(tokens)


def estimate_tokens_messages(messages: List[Dict[str, str]]) -> int:
    """
    Estimate tokens for message list
    
    Args:
        messages: List of messages with 'role' and 'content'
        
    Returns:
        Total estimated tokens
    """
    total = 0
    for msg in messages:
        # Add overhead for role formatting
        overhead = len(msg.get('role', '')) + 10
        total += estimate_tokens(msg.get('content', '')) + overhead
    
    return total


# ========== Text Processing ==========

def truncate_text(text: str, max_tokens: int, 
                 tokenizer: callable = None) -> str:
    """
    Truncate text to fit within token limit
    
    Args:
        text: Input text
        max_tokens: Maximum tokens allowed
        tokenizer: Token counting function (defaults to estimate_tokens)
        
    Returns:
        Truncated text
    """
    if tokenizer is None:
        tokenizer = estimate_tokens
    
    tokens = tokenizer(text)
    if tokens <= max_tokens:
        return text
    
    # Binary search for optimal truncation
    words = text.split()
    low, high = 0, len(words)
    
    while low < high:
        mid = (low + high + 1) // 2
        truncated = ' '.join(words[:mid])
        if tokenizer(truncated) <= max_tokens:
            low = mid
        else:
            high = mid - 1
    
    return ' '.join(words[:low])


def normalize_whitespace(text: str) -> str:
    """Normalize whitespace in text"""
    # Replace multiple spaces with single space
    text = re.sub(r'\s+', ' ', text)
    # Remove leading/trailing whitespace
    text = text.strip()
    return text


def extract_code_blocks(text: str) -> List[Dict[str, str]]:
    """
    Extract code blocks from markdown text
    
    Args:
        text: Markdown text
        
    Returns:
        List of {'language': str, 'code': str}
    """
    pattern = r'```(\w+)?\n(.*?)```'
    matches = re.findall(pattern, text, re.DOTALL)
    
    blocks = []
    for lang, code in matches:
        blocks.append({
            'language': lang or 'text',
            'code': code.strip()
        })
    
    return blocks


# ========== JSON Helpers ==========

def parse_json_safely(text: str) -> Tuple[Optional[Dict], Optional[str]]:
    """
    Safely parse JSON with error handling
    
    Args:
        text: JSON string
        
    Returns:
        (parsed_data, error_message)
    """
    try:
        # Try direct parsing
        return json.loads(text), None
    except json.JSONDecodeError as e:
        # Try to extract JSON from markdown code blocks
        match = re.search(r'```(?:json)?\s*\n(.*?)\n```', text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(1)), None
            except json.JSONDecodeError:
                return None, f"Invalid JSON: {e}"
        
        return None, f"Parse error: {e}"


def format_json(data: Any, indent: int = 2) -> str:
    """Format data as pretty JSON"""
    return json.dumps(data, indent=indent, ensure_ascii=False)


# ========== ID Generation ==========

def generate_id(prefix: str = "") -> str:
    """Generate a unique ID with optional prefix"""
    uid = str(uuid.uuid4())[:8]
    return f"{prefix}{uid}" if prefix else uid


def generate_session_id() -> str:
    """Generate session ID"""
    return f"session-{generate_id()}"


def generate_agent_id() -> str:
    """Generate agent ID"""
    return f"agent-{generate_id()}"


def generate_checkpoint_id() -> str:
    """Generate checkpoint ID"""
    return f"cp-{generate_id()}"


# ========== Time Utilities ==========

def format_duration(seconds: float) -> str:
    """
    Format duration in human-readable format
    
    Args:
        seconds: Duration in seconds
        
    Returns:
        Formatted string like "2h 30m 15s"
    """
    if seconds < 60:
        return f"{seconds:.0f}s"
    elif seconds < 3600:
        minutes = int(seconds // 60)
        secs = int(seconds % 60)
        return f"{minutes}m {secs}s"
    elif seconds < 86400:
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        return f"{hours}h {minutes}m"
    else:
        days = int(seconds // 86400)
        hours = int((seconds % 86400) // 3600)
        return f"{days}d {hours}h"


def format_timestamp(timestamp: float = None, 
                    format: str = "iso") -> str:
    """
    Format timestamp
    
    Args:
        timestamp: Unix timestamp (defaults to now)
        format: "iso", "human", "unix"
        
    Returns:
        Formatted timestamp string
    """
    dt = datetime.fromtimestamp(timestamp or time.time())
    
    if format == "iso":
        return dt.isoformat()
    elif format == "human":
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    elif format == "unix":
        return str(int(timestamp or time.time()))
    else:
        return dt.isoformat()


# ========== Hash and Crypto ==========

def hash_text(text: str) -> str:
    """Create SHA-256 hash of text"""
    return hashlib.sha256(text.encode()).hexdigest()


def hash_dict(data: Dict) -> str:
    """Create hash of dictionary"""
    return hash_text(json.dumps(data, sort_keys=True))


# ========== Validation ==========

def is_valid_url(url: str) -> bool:
    """Check if string is valid URL"""
    pattern = r'^https?://[\w.-]+(/[\w./-]*)?$'
    return bool(re.match(pattern, url))


def is_valid_email(email: str) -> bool:
    """Check if string is valid email"""
    pattern = r'^[\w.-]+@[\w.-]+\.\w+$'
    return bool(re.match(pattern, email))


# ========== File Operations ==========

def read_file_safely(filepath: str, 
                    encoding: str = 'utf-8') -> Tuple[Optional[str], Optional[str]]:
    """
    Read file with error handling
    
    Returns:
        (content, error_message)
    """
    try:
        with open(filepath, 'r', encoding=encoding) as f:
            return f.read(), None
    except FileNotFoundError:
        return None, f"File not found: {filepath}"
    except PermissionError:
        return None, f"Permission denied: {filepath}"
    except Exception as e:
        return None, f"Error reading {filepath}: {e}"


def write_file_safely(filepath: str, 
                     content: str,
                     encoding: str = 'utf-8') -> Tuple[bool, Optional[str]]:
    """
    Write file with error handling
    
    Returns:
        (success, error_message)
    """
    try:
        with open(filepath, 'w', encoding=encoding) as f:
            f.write(content)
        return True, None
    except PermissionError:
        return False, f"Permission denied: {filepath}"
    except Exception as e:
        return False, f"Error writing {filepath}: {e}"


# ========== Progress Tracking ==========

class ProgressTracker:
    """Simple progress tracker"""
    
    def __init__(self, total: int, 
                 description: str = "Progress"):
        """
        Initialize tracker
        
        Args:
            total: Total items
            description: Description shown in progress
        """
        self.total = total
        self.current = 0
        self.description = description
        self.start_time = time.time()
        self.last_update = self.start_time
    
    def update(self, n: int = 1, 
               description: str = None):
        """
        Update progress
        
        Args:
            n: Number of items completed
            description: Override description
        """
        self.current = min(self.current + n, self.total)
        self.last_update = time.time()
        if description:
            self.description = description
    
    def progress(self) -> float:
        """Get progress as 0-1 float"""
        return self.current / self.total if self.total > 0 else 1.0
    
    def eta(self) -> float:
        """Get estimated time to completion in seconds"""
        elapsed = time.time() - self.start_time
        if self.current >= self.total:
            return 0
        rate = self.current / elapsed if elapsed > 0 else 0
        remaining = self.total - self.current
        return remaining / rate if rate > 0 else float('inf')
    
    def __str__(self) -> str:
        """Get progress string"""
        pct = self.progress() * 100
        eta = format_duration(self.eta())
        return f"{self.description}: {self.current}/{self.total} ({pct:.1f}%) ETA: {eta}"


# ========== Export ==========

__all__ = [
    # Token estimation
    "estimate_tokens",
    "estimate_tokens_messages",
    "truncate_text",
    
    # Text processing
    "normalize_whitespace",
    "extract_code_blocks",
    
    # JSON helpers
    "parse_json_safely",
    "format_json",
    
    # ID generation
    "generate_id",
    "generate_session_id",
    "generate_agent_id",
    "generate_checkpoint_id",
    
    # Time utilities
    "format_duration",
    "format_timestamp",
    
    # Hashing
    "hash_text",
    "hash_dict",
    
    # Validation
    "is_valid_url",
    "is_valid_email",
    
    # File operations
    "read_file_safely",
    "write_file_safely",
    
    # Progress tracking
    "ProgressTracker",
]
