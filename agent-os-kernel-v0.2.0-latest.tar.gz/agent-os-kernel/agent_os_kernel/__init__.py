# -*- coding: utf-8 -*-
"""
Agent OS Kernel - AI Agent 的操作系统内核
"""

__version__ = "0.2.0"
__author__ = "Bit-Cook"
__license__ = "MIT"

# 主内核
from .kernel import AgentOSKernel, KernelStats

# 监控指标
from .core.metrics import (
    MetricsCollector,
    Metric,
    default_metrics,
    get_metrics,
)

__all__ = [
    "__version__",
    "__author__",
    "__license__",
    "AgentOSKernel",
    "KernelStats",
    "MetricsCollector",
    "Metric",
    "default_metrics",
    "get_metrics",
]
