# -*- coding: utf-8 -*-
"""
Configuration Module - Agent OS Kernel

YAML config file support with environment variable overrides.
"""

import os
import yaml
import logging
from pathlib import Path
from typing import Any, Dict, Optional, List
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class DatabaseConfig:
    """Database configuration"""
    connection_string: str = "postgresql://localhost:5432/agent_os"
    pool_size: int = 10
    max_overflow: int = 20
    enable_vector: bool = True
    vector_dimensions: int = 1536
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'connection_string': self.connection_string,
            'pool_size': self.pool_size,
            'max_overflow': self.max_overflow,
            'enable_vector': self.enable_vector,
            'vector_dimensions': self.vector_dimensions,
        }


@dataclass
class ContextConfig:
    """Context manager configuration"""
    max_context_tokens: int = 128000
    enable_semantic_importance: bool = False
    swap_threshold: float = 0.8
    l1_cache_size: int = 1000
    l2_cache_size: int = 20000
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'max_context_tokens': self.max_context_tokens,
            'enable_semantic_importance': self.enable_semantic_importance,
            'swap_threshold': self.swap_threshold,
            'l1_cache_size': self.l1_cache_size,
            'l2_cache_size': self.l2_cache_size,
        }


@dataclass
class SchedulerConfig:
    """Scheduler configuration"""
    time_slice: float = 60.0
    max_concurrent_agents: int = 10
    quota_window_seconds: int = 3600
    max_tokens_per_window: int = 100000
    max_api_calls_per_window: int = 1000
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'time_slice': self.time_slice,
            'max_concurrent_agents': self.max_concurrent_agents,
            'quota_window_seconds': self.quota_window_seconds,
            'max_tokens_per_window': self.max_tokens_per_window,
            'max_api_calls_per_window': self.max_api_calls_per_window,
        }


@dataclass
class SecurityConfig:
    """Security configuration"""
    enable_sandbox: bool = False
    sandbox_type: str = "docker"
    allowed_tools: List[str] = field(default_factory=lambda: ["*"])
    disallowed_tools: List[str] = field(default_factory=list)
    max_file_size_mb: int = 100
    network_policy: str = "restricted"
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'enable_sandbox': self.enable_sandbox,
            'sandbox_type': self.sandbox_type,
            'allowed_tools': self.allowed_tools,
            'disallowed_tools': self.disallowed_tools,
            'max_file_size_mb': self.max_file_size_mb,
            'network_policy': self.network_policy,
        }


@dataclass
class LoggingConfig:
    """Logging configuration"""
    level: str = "INFO"
    format: str = "[%(asctime)s] [%(name)s] %(levelname)s: %(message)s"
    file: Optional[str] = None
    max_size_mb: int = 100
    backup_count: int = 5
    enable_audit: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'level': self.level,
            'format': self.format,
            'file': self.file,
            'max_size_mb': self.max_size_mb,
            'backup_count': self.backup_count,
            'enable_audit': self.enable_audit,
        }


@dataclass
class MetricsConfig:
    """Metrics configuration"""
    enabled: bool = True
    port: int = 9090
    path: str = "/metrics"
    include_tokens: bool = True
    include_latency: bool = True
    include_custom: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'enabled': self.enabled,
            'port': self.port,
            'path': self.path,
            'include_tokens': self.include_tokens,
            'include_latency': self.include_latency,
            'include_custom': self.include_custom,
        }


@dataclass
class IntegrationConfig:
    """LLM Integration configuration"""
    default_provider: str = "claude"
    default_model: str = "claude-sonnet-4-20250514"
    api_key_env: str = ""
    timeout: int = 60
    max_retries: int = 3
    enable_streaming: bool = True
    enable_function_calling: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'default_provider': self.default_provider,
            'default_model': self.default_model,
            'api_key_env': self.api_key_env,
            'timeout': self.timeout,
            'max_retries': self.max_retries,
            'enable_streaming': self.enable_streaming,
            'enable_function_calling': self.enable_function_calling,
        }


@dataclass
class AgentOSConfig:
    """Main configuration class"""
    version: str = "0.2.0"
    name: str = "Agent OS Kernel"
    environment: str = "development"
    
    database: DatabaseConfig = field(default_factory=DatabaseConfig)
    context: ContextConfig = field(default_factory=ContextConfig)
    scheduler: SchedulerConfig = field(default_factory=SchedulerConfig)
    security: SecurityConfig = field(default_factory=SecurityConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)
    metrics: MetricsConfig = field(default_factory=MetricsConfig)
    integration: IntegrationConfig = field(default_factory=IntegrationConfig)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'version': self.version,
            'name': self.name,
            'environment': self.environment,
            'database': self.database.to_dict(),
            'context': self.context.to_dict(),
            'scheduler': self.scheduler.to_dict(),
            'security': self.security.to_dict(),
            'logging': self.logging.to_dict(),
            'metrics': self.metrics.to_dict(),
            'integration': self.integration.to_dict(),
        }


class ConfigLoader:
    """Configuration loader with YAML and environment variable support"""
    
    DEFAULT_CONFIG_FILES = [
        "agent-os-config.yaml",
        "config.yaml",
        ".agent-os-config.yaml",
    ]
    
    ENV_PREFIX = "AGENT_OS_"
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize configuration loader
        
        Args:
            config_path: Path to config file (optional)
        """
        self.config = AgentOSConfig()
        self.config_path = config_path
        self._load_config()
    
    def _find_config_file(self) -> Optional[Path]:
        """Find configuration file"""
        if self.config_path:
            path = Path(self.config_path)
            if path.exists():
                return path
            return None
        
        # Search in default locations
        for filename in self.DEFAULT_CONFIG_FILES:
            # Check current directory
            path = Path.cwd() / filename
            if path.exists():
                return path
            
            # Check home directory
            home_path = Path.home() / f".config/agent-os/{filename}"
            if home_path.exists():
                return home_path
            
            # Check /etc
            etc_path = Path(f"/etc/agent-os/{filename}")
            if etc_path.exists():
                return etc_path
        
        return None
    
    def _load_config(self):
        """Load configuration from file and environment"""
        config_file = self._find_config_file()
        
        if config_file:
            self._load_yaml(config_file)
        
        # Apply environment variable overrides
        self._apply_env_overrides()
    
    def _load_yaml(self, path: Path):
        """Load configuration from YAML file"""
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
            
            if data:
                self._apply_dict_config(data)
                logger.info(f"Loaded configuration from {path}")
        except Exception as e:
            logger.warning(f"Failed to load config from {path}: {e}")
    
    def _apply_dict_config(self, data: Dict[str, Any]):
        """Apply dictionary configuration to dataclasses"""
        # Database
        if 'database' in data:
            db_data = data['database']
            self.config.database = DatabaseConfig(
                connection_string=db_data.get('connection_string', self.config.database.connection_string),
                pool_size=db_data.get('pool_size', self.config.database.pool_size),
                max_overflow=db_data.get('max_overflow', self.config.database.max_overflow),
                enable_vector=db_data.get('enable_vector', self.config.database.enable_vector),
                vector_dimensions=db_data.get('vector_dimensions', self.config.database.vector_dimensions),
            )
        
        # Context
        if 'context' in data:
            ctx_data = data['context']
            self.config.context = ContextConfig(
                max_context_tokens=ctx_data.get('max_context_tokens', self.config.context.max_context_tokens),
                enable_semantic_importance=ctx_data.get('enable_semantic_importance', self.config.context.enable_semantic_importance),
                swap_threshold=ctx_data.get('swap_threshold', self.config.context.swap_threshold),
                l1_cache_size=ctx_data.get('l1_cache_size', self.config.context.l1_cache_size),
                l2_cache_size=ctx_data.get('l2_cache_size', self.config.context.l2_cache_size),
            )
        
        # Scheduler
        if 'scheduler' in data:
            sched_data = data['scheduler']
            self.config.scheduler = SchedulerConfig(
                time_slice=sched_data.get('time_slice', self.config.scheduler.time_slice),
                max_concurrent_agents=sched_data.get('max_concurrent_agents', self.config.scheduler.max_concurrent_agents),
                quota_window_seconds=sched_data.get('quota_window_seconds', self.config.scheduler.quota_window_seconds),
                max_tokens_per_window=sched_data.get('max_tokens_per_window', self.config.scheduler.max_tokens_per_window),
                max_api_calls_per_window=sched_data.get('max_api_calls_per_window', self.config.scheduler.max_api_calls_per_window),
            )
        
        # Security
        if 'security' in data:
            sec_data = data['security']
            self.config.security = SecurityConfig(
                enable_sandbox=sec_data.get('enable_sandbox', self.config.security.enable_sandbox),
                sandbox_type=sec_data.get('sandbox_type', self.config.security.sandbox_type),
                allowed_tools=sec_data.get('allowed_tools', self.config.security.allowed_tools),
                disallowed_tools=sec_data.get('disallowed_tools', self.config.security.disallowed_tools),
                max_file_size_mb=sec_data.get('max_file_size_mb', self.config.security.max_file_size_mb),
                network_policy=sec_data.get('network_policy', self.config.security.network_policy),
            )
        
        # Logging
        if 'logging' in data:
            log_data = data['logging']
            self.config.logging = LoggingConfig(
                level=log_data.get('level', self.config.logging.level),
                format=log_data.get('format', self.config.logging.format),
                file=log_data.get('file', self.config.logging.file),
                max_size_mb=log_data.get('max_size_mb', self.config.logging.max_size_mb),
                backup_count=log_data.get('backup_count', self.config.logging.backup_count),
                enable_audit=log_data.get('enable_audit', self.config.logging.enable_audit),
            )
        
        # Metrics
        if 'metrics' in data:
            met_data = data['metrics']
            self.config.metrics = MetricsConfig(
                enabled=met_data.get('enabled', self.config.metrics.enabled),
                port=met_data.get('port', self.config.metrics.port),
                path=met_data.get('path', self.config.metrics.path),
                include_tokens=met_data.get('include_tokens', self.config.metrics.include_tokens),
                include_latency=met_data.get('include_latency', self.config.metrics.include_latency),
                include_custom=met_data.get('include_custom', self.config.metrics.include_custom),
            )
        
        # Integration
        if 'integration' in data:
            int_data = data['integration']
            self.config.integration = IntegrationConfig(
                default_provider=int_data.get('default_provider', self.config.integration.default_provider),
                default_model=int_data.get('default_model', self.config.integration.default_model),
                api_key_env=int_data.get('api_key_env', self.config.integration.api_key_env),
                timeout=int_data.get('timeout', self.config.integration.timeout),
                max_retries=int_data.get('max_retries', self.config.integration.max_retries),
                enable_streaming=int_data.get('enable_streaming', self.config.integration.enable_streaming),
                enable_function_calling=int_data.get('enable_function_calling', self.config.integration.enable_function_calling),
            )
        
        # General settings
        if 'name' in data:
            self.config.name = data['name']
        if 'environment' in data:
            self.config.environment = data['environment']
    
    def _apply_env_overrides(self):
        """Apply environment variable overrides"""
        env_mappings = {
            'AGENT_OS_DATABASE_CONNECTION_STRING': ('database', 'connection_string', str),
            'AGENT_OS_DATABASE_POOL_SIZE': ('database', 'pool_size', int),
            'AGENT_OS_DATABASE_ENABLE_VECTOR': ('database', 'enable_vector', bool),
            'AGENT_OS_CONTEXT_MAX_TOKENS': ('context', 'max_context_tokens', int),
            'AGENT_OS_SCHEDULER_TIME_SLICE': ('scheduler', 'time_slice', float),
            'AGENT_OS_SCHEDULER_MAX_AGENTS': ('scheduler', 'max_concurrent_agents', int),
            'AGENT_OS_SECURITY_ENABLE_SANDBOX': ('security', 'enable_sandbox', bool),
            'AGENT_OS_LOGGING_LEVEL': ('logging', 'level', str),
            'AGENT_OS_METRICS_ENABLED': ('metrics', 'enabled', bool),
            'AGENT_OS_METRICS_PORT': ('metrics', 'port', int),
            'AGENT_OS_INTEGRATION_PROVIDER': ('integration', 'default_provider', str),
            'AGENT_OS_INTEGRATION_MODEL': ('integration', 'default_model', str),
            'AGENT_OS_INTEGRATION_TIMEOUT': ('integration', 'timeout', int),
        }
        
        for env_var, (section, key, type_fn) in env_mappings.items():
            value = os.environ.get(env_var)
            if value is not None:
                try:
                    # Convert to proper type
                    if type_fn == bool:
                        parsed_value = value.lower() in ('true', '1', 'yes')
                    else:
                        parsed_value = type_fn(value)
                    
                    # Apply to config
                    section_config = getattr(self.config, section)
                    setattr(section_config, key, parsed_value)
                    logger.debug(f"Applied env override: {env_var} -> {section}.{key}")
                except Exception as e:
                    logger.warning(f"Failed to apply env override {env_var}: {e}")
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value by dot-notation key"""
        keys = key.split('.')
        current = self.config
        
        for k in keys:
            if isinstance(current, dict):
                current = current.get(k)
            elif hasattr(current, k):
                current = getattr(current, k)
            else:
                return default
        
        return current
    
    def set(self, key: str, value: Any):
        """Set configuration value by dot-notation key"""
        keys = key.split('.')
        section_key = keys[0]
        attr_path = keys[1:] if len(keys) > 1 else []
        
        section = getattr(self.config, section_key)
        
        if attr_path:
            # Navigate to nested attribute
            for attr in attr_path[:-1]:
                section = getattr(section, attr)
            setattr(section, attr_path[-1], value)
        else:
            setattr(self.config, section_key, value)
    
    def save(self, path: Optional[str] = None):
        """Save configuration to YAML file"""
        save_path = Path(path) if path else Path.cwd() / "agent-os-config.yaml"
        
        with open(save_path, 'w', encoding='utf-8') as f:
            yaml.dump(self.config.to_dict(), f, default_flow_style=False, indent=2)
        
        logger.info(f"Saved configuration to {save_path}")
    
    @property
    def database(self) -> DatabaseConfig:
        return self.config.database
    
    @property
    def context(self) -> ContextConfig:
        return self.config.context
    
    @property
    def scheduler(self) -> SchedulerConfig:
        return self.config.scheduler
    
    @property
    def security(self) -> SecurityConfig:
        return self.config.security
    
    @property
    def logging_config(self) -> LoggingConfig:
        return self.config.logging
    
    @property
    def metrics(self) -> MetricsConfig:
        return self.config.metrics
    
    @property
    def integration(self) -> IntegrationConfig:
        return self.config.integration


# Convenience function
def load_config(config_path: Optional[str] = None) -> ConfigLoader:
    """Load configuration from file and environment"""
    return ConfigLoader(config_path)


# Default config template
DEFAULT_CONFIG_TEMPLATE = """# Agent OS Kernel Configuration
# Generated by Agent OS Kernel

version: 0.2.0
name: Agent OS Kernel
environment: development

database:
  connection_string: postgresql://localhost:5432/agent_os
  pool_size: 10
  max_overflow: 20
  enable_vector: true
  vector_dimensions: 1536

context:
  max_context_tokens: 128000
  enable_semantic_importance: false
  swap_threshold: 0.8
  l1_cache_size: 1000
  l2_cache_size: 20000

scheduler:
  time_slice: 60.0
  max_concurrent_agents: 10
  quota_window_seconds: 3600
  max_tokens_per_window: 100000
  max_api_calls_per_window: 1000

security:
  enable_sandbox: false
  sandbox_type: docker
  allowed_tools:
    - "*"
  disallowed_tools: []
  max_file_size_mb: 100
  network_policy: restricted

logging:
  level: INFO
  format: "[%(asctime)s] [%(name)s] %(levelname)s: %(message)s"
  file: null
  max_size_mb: 100
  backup_count: 5
  enable_audit: true

metrics:
  enabled: true
  port: 9090
  path: /metrics
  include_tokens: true
  include_latency: true
  include_custom: true

integration:
  default_provider: claude
  default_model: claude-sonnet-4-20250514
  api_key_env: ""
  timeout: 60
  max_retries: 3
  enable_streaming: true
  enable_function_calling: true
"""


# Convenience wrapper class
class KernelConfig:
    """Convenience wrapper for accessing all configuration sections"""
    
    def __init__(self):
        self.database = DatabaseConfig()
        self.context = ContextConfig()
        self.scheduler = SchedulerConfig()
        self.security = SecurityConfig()
        self.logging = LoggingConfig()
        self.metrics = MetricsConfig()
        self.integration = IntegrationConfig()
        self.version = "0.2.0"
        self.name = "Agent OS Kernel"
        self.environment = "development"
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'KernelConfig':
        """Create config from dictionary"""
        config = cls()
        
        if 'database' in data:
            for key, value in data['database'].items():
                if hasattr(config.database, key):
                    setattr(config.database, key, value)
        
        if 'context' in data:
            for key, value in data['context'].items():
                if hasattr(config.context, key):
                    setattr(config.context, key, value)
        
        if 'scheduler' in data:
            for key, value in data['scheduler'].items():
                if hasattr(config.scheduler, key):
                    setattr(config.scheduler, key, value)
        
        if 'security' in data:
            for key, value in data['security'].items():
                if hasattr(config.security, key):
                    setattr(config.security, key, value)
        
        if 'metrics' in data:
            for key, value in data['metrics'].items():
                if hasattr(config.metrics, key):
                    setattr(config.metrics, key, value)
        
        if 'integration' in data:
            for key, value in data['integration'].items():
                if hasattr(config.integration, key):
                    setattr(config.integration, key, value)
        
        return config
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'version': self.version,
            'name': self.name,
            'environment': self.environment,
            'database': self.database.to_dict(),
            'context': self.context.to_dict(),
            'scheduler': self.scheduler.to_dict(),
            'security': self.security.to_dict(),
            'logging': self.logging.to_dict(),
            'metrics': self.metrics.to_dict(),
            'integration': self.integration.to_dict(),
        }
    
    def get_nested(self, key: str, default: Any = None) -> Any:
        """Get nested config value using dot notation"""
        keys = key.split('.')
        obj = self
        for k in keys:
            if hasattr(obj, k):
                obj = getattr(obj, k)
            else:
                return default
        return obj
    
    def set_nested(self, key: str, value: Any):
        """Set nested config value using dot notation"""
        keys = key.split('.')
        obj = self
        for k in keys[:-1]:
            if hasattr(obj, k):
                obj = getattr(obj, k)
        if hasattr(obj, keys[-1]):
            setattr(obj, keys[-1], value)


class ConfigError(Exception):
    """Configuration error"""
    pass


# Environment variable override
class EnvironmentConfigOverride:
    """Apply environment variable overrides to config"""
    
    PREFIX = "AGENT_OS_"
    
    def __init__(self, prefix: str = None):
        self.prefix = prefix or self.PREFIX
    
    def apply(self, config: KernelConfig, 
              key_mapping: Dict[str, tuple] = None) -> KernelConfig:
        """Apply environment overrides to config"""
        if key_mapping is None:
            key_mapping = {
                'CONTEXT_TOKENS': ('context.max_context_tokens', int),
                'TIME_SLICE': ('scheduler.time_slice', float),
                'MAX_AGENTS': ('scheduler.max_concurrent_agents', int),
                'STORAGE_TYPE': ('integration.default_provider', str),
                'LOG_LEVEL': ('logging.level', str),
                'METRICS_PORT': ('metrics.port', int),
            }
        
        for env_key, (config_path, type_func) in key_mapping.items():
            full_key = self.prefix + env_key
            if full_key in os.environ:
                try:
                    value = type_func(os.environ[full_key])
                    parts = config_path.split('.')
                    obj = config
                    for part in parts[:-1]:
                        obj = getattr(obj, part)
                    setattr(obj, parts[-1], value)
                except (ValueError, TypeError):
                    pass
        
        return config
    
    @staticmethod
    def mask_sensitive(value: str) -> str:
        """Mask sensitive values in config"""
        import re
        masked = re.sub(r':([^:@]+)@', ':******@', value)
        return masked


# Default configuration
DEFAULT_CONFIG = {
    'version': '0.2.0',
    'name': 'Agent OS Kernel',
    'environment': 'development',
    'database': {
        'connection_string': 'postgresql://localhost:5432/agent_os',
        'pool_size': 10,
        'enable_vector': True,
    },
    'context': {
        'max_context_tokens': 128000,
        'min_context_tokens': 1000,
        'enable_semantic_importance': False,
    },
    'scheduler': {
        'time_slice': 60.0,
        'max_concurrent_agents': 10,
    },
    'metrics': {
        'enabled': True,
        'port': 9090,
    },
    'logging': {
        'level': 'INFO',
    },
    'security': {
        'enable_sandbox': False,
    },
    'integration': {
        'default_provider': 'claude',
        'timeout': 60,
        'max_retries': 3,
    }
}
