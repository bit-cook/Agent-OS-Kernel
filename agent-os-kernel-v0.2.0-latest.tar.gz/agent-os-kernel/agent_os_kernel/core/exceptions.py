# -*- coding: utf-8 -*-
"""
Exception Hierarchy - Agent OS Kernel

Custom exceptions with error codes and messages.
"""

from typing import Optional, Dict, Any
from enum import Enum


class ErrorCode(Enum):
    """Error codes for Agent OS Kernel"""
    
    # General errors (0-999)
    SUCCESS = (0, "Success")
    UNKNOWN_ERROR = (1, "Unknown error")
    INVALID_ARGUMENT = (2, "Invalid argument")
    NOT_IMPLEMENTED = (3, "Not implemented")
    CONFIG_ERROR = (4, "Configuration error")
    
    # Context Manager errors (1000-1999)
    CONTEXT_FULL = (1001, "Context window is full")
    PAGE_NOT_FOUND = (1002, "Page not found")
    SWAP_FAILED = (1003, "Failed to swap page")
    PAGE_CORRUPTED = (1004, "Page data is corrupted")
    INVALID_PAGE_TYPE = (1005, "Invalid page type")
    
    # Scheduler errors (2000-2999)
    PROCESS_NOT_FOUND = (2001, "Process not found")
    PROCESS_TERMINATED = (2002, "Process has been terminated")
    QUOTA_EXCEEDED = (2003, "Resource quota exceeded")
    SCHEDULER_ERROR = (2004, "Scheduler error")
    DEADLOCK_DETECTED = (2005, "Deadlock detected")
    TIMEOUT_EXPIRED = (2006, "Timeout expired")
    
    # Storage errors (3000-3999)
    STORAGE_CONNECTION_FAILED = (3001, "Failed to connect to storage")
    STORAGE_QUERY_FAILED = (3002, "Storage query failed")
    CHECKPOINT_NOT_FOUND = (3003, "Checkpoint not found")
    CHECKPOINT_CORRUPTED = (3004, "Checkpoint data is corrupted")
    TRANSACTION_FAILED = (3005, "Transaction failed")
    VECTOR_SEARCH_FAILED = (3006, "Vector search failed")
    
    # Security errors (4000-4999)
    PERMISSION_DENIED = (4001, "Permission denied")
    SANDBOX_ERROR = (4002, "Sandbox error")
    TOOL_BLOCKED = (4003, "Tool is blocked by security policy")
    INVALID_CREDENTIALS = (4004, "Invalid credentials")
    RATE_LIMITED = (4005, "Rate limit exceeded")
    
    # Integration errors (5000-5999)
    API_CALL_FAILED = (5001, "API call failed")
    API_TIMEOUT = (5002, "API timeout")
    API_RATE_LIMITED = (5003, "API rate limit exceeded")
    INVALID_API_KEY = (5004, "Invalid API key")
    MODEL_NOT_FOUND = (5005, "Model not found")
    STREAMING_ERROR = (5006, "Streaming error")
    FUNCTION_CALL_FAILED = (5007, "Function call failed")
    
    # Tool errors (6000-6999)
    TOOL_NOT_FOUND = (6001, "Tool not found")
    TOOL_EXECUTION_FAILED = (6002, "Tool execution failed")
    TOOL_TIMEOUT = (6003, "Tool execution timeout")
    TOOL_INVALID_PARAMS = (6004, "Invalid tool parameters")
    
    @property
    def code(self) -> int:
        return self.value[0]
    
    @property
    def message(self) -> str:
        return self.value[1]


class AgentOSError(Exception):
    """Base exception for Agent OS Kernel"""
    
    def __init__(self, 
                 message: str = "",
                 error_code: ErrorCode = ErrorCode.UNKNOWN_ERROR,
                 details: Optional[Dict] = None,
                 cause: Optional[Exception] = None):
        """
        Initialize exception
        
        Args:
            message: Custom error message
            error_code: Error code
            details: Additional error details
            cause: Original exception that caused this error
        """
        self.error_code = error_code
        self.details = details or {}
        self.cause = cause
        
        # Use custom message or default from error code
        if message:
            self.message = message
        else:
            self.message = error_code.message
        
        super().__init__(self.message)
    
    def __str__(self) -> str:
        return f"[{self.error_code.code}] {self.message}"
    
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(message={self.message!r}, code={self.error_code.code})"
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'error_code': self.error_code.code,
            'error_name': self.error_code.name,
            'message': self.message,
            'details': self.details,
            'cause': str(self.cause) if self.cause else None,
        }


class ContextError(AgentOSError):
    """Base exception for context manager errors"""
    
    def __init__(self, message: str, error_code: ErrorCode = ErrorCode.UNKNOWN_ERROR, **kwargs):
        super().__init__(message=message, error_code=error_code, **kwargs)


class ContextFullError(ContextError):
    """Raised when context window is full"""
    
    def __init__(self, current_usage: int, max_tokens: int, **kwargs):
        message = f"Context window full: {current_usage}/{max_tokens} tokens"
        super().__init__(
            message=message,
            error_code=ErrorCode.CONTEXT_FULL,
            details={'current_usage': current_usage, 'max_tokens': max_tokens},
            **kwargs
        )


class PageNotFoundError(ContextError):
    """Raised when page is not found"""
    
    def __init__(self, page_id: str, **kwargs):
        message = f"Page not found: {page_id}"
        super().__init__(
            message=message,
            error_code=ErrorCode.PAGE_NOT_FOUND,
            details={'page_id': page_id},
            **kwargs
        )


class SwapError(ContextError):
    """Raised when page swap fails"""
    
    def __init__(self, page_id: str, operation: str = "swap", **kwargs):
        message = f"Failed to {operation} page: {page_id}"
        super().__init__(
            message=message,
            error_code=ErrorCode.SWAP_FAILED,
            details={'page_id': page_id, 'operation': operation},
            **kwargs
        )


class SchedulerError(AgentOSError):
    """Base exception for scheduler errors"""
    
    def __init__(self, message: str, error_code: ErrorCode = ErrorCode.SCHEDULER_ERROR, **kwargs):
        super().__init__(message=message, error_code=error_code, **kwargs)


class ProcessNotFoundError(SchedulerError):
    """Raised when process is not found"""
    
    def __init__(self, pid: str, **kwargs):
        message = f"Process not found: {pid}"
        super().__init__(
            message=message,
            error_code=ErrorCode.PROCESS_NOT_FOUND,
            details={'pid': pid},
            **kwargs
        )


class ProcessTerminatedError(SchedulerError):
    """Raised when trying to operate on a terminated process"""
    
    def __init__(self, pid: str, **kwargs):
        message = f"Process has been terminated: {pid}"
        super().__init__(
            message=message,
            error_code=ErrorCode.PROCESS_TERMINATED,
            details={'pid': pid},
            **kwargs
        )


class QuotaExceededError(SchedulerError):
    """Raised when resource quota is exceeded"""
    
    def __init__(self, resource_type: str, current: int, limit: int, **kwargs):
        message = f"{resource_type} quota exceeded: {current}/{limit}"
        super().__init__(
            message=message,
            error_code=ErrorCode.QUOTA_EXCEEDED,
            details={'resource_type': resource_type, 'current': current, 'limit': limit},
            **kwargs
        )


class StorageError(AgentOSError):
    """Base exception for storage errors"""
    
    def __init__(self, message: str, error_code: ErrorCode = ErrorCode.STORAGE_QUERY_FAILED, **kwargs):
        super().__init__(message=message, error_code=error_code, **kwargs)


class StorageConnectionError(StorageError):
    """Raised when storage connection fails"""
    
    def __init__(self, backend: str, reason: str = "", **kwargs):
        message = f"Failed to connect to {backend} storage"
        if reason:
            message += f": {reason}"
        super().__init__(
            message=message,
            error_code=ErrorCode.STORAGE_CONNECTION_FAILED,
            details={'backend': backend, 'reason': reason},
            **kwargs
        )


class CheckpointNotFoundError(StorageError):
    """Raised when checkpoint is not found"""
    
    def __init__(self, checkpoint_id: str, **kwargs):
        message = f"Checkpoint not found: {checkpoint_id}"
        super().__init__(
            message=message,
            error_code=ErrorCode.CHECKPOINT_NOT_FOUND,
            details={'checkpoint_id': checkpoint_id},
            **kwargs
        )


class SecurityError(AgentOSError):
    """Base exception for security errors"""
    
    def __init__(self, message: str, error_code: ErrorCode = ErrorCode.PERMISSION_DENIED, **kwargs):
        super().__init__(message=message, error_code=error_code, **kwargs)


class PermissionDeniedError(SecurityError):
    """Raised when permission is denied"""
    
    def __init__(self, operation: str, resource: str = "", **kwargs):
        message = f"Permission denied: {operation}"
        if resource:
            message += f" on {resource}"
        super().__init__(
            message=message,
            error_code=ErrorCode.PERMISSION_DENIED,
            details={'operation': operation, 'resource': resource},
            **kwargs
        )


class ToolBlockedError(SecurityError):
    """Raised when a tool is blocked by security policy"""
    
    def __init__(self, tool_name: str, reason: str = "", **kwargs):
        message = f"Tool blocked: {tool_name}"
        if reason:
            message += f" ({reason})"
        super().__init__(
            message=message,
            error_code=ErrorCode.TOOL_BLOCKED,
            details={'tool_name': tool_name, 'reason': reason},
            **kwargs
        )


class RateLimitError(SecurityError):
    """Raised when rate limit is exceeded"""
    
    def __init__(self, limit_type: str, limit: int, retry_after: Optional[int] = None, **kwargs):
        message = f"Rate limit exceeded for {limit_type}"
        super().__init__(
            message=message,
            error_code=ErrorCode.RATE_LIMITED,
            details={'limit_type': limit_type, 'limit': limit, 'retry_after': retry_after},
            **kwargs
        )


class IntegrationError(AgentOSError):
    """Base exception for integration errors"""
    
    def __init__(self, message: str, error_code: ErrorCode = ErrorCode.API_CALL_FAILED, **kwargs):
        super().__init__(message=message, error_code=error_code, **kwargs)


class APICallError(IntegrationError):
    """Raised when API call fails"""
    
    def __init__(self, provider: str, model: str, status_code: int = 500, **kwargs):
        message = f"API call failed: {provider}/{model} (status: {status_code})"
        super().__init__(
            message=message,
            error_code=ErrorCode.API_CALL_FAILED,
            details={'provider': provider, 'model': model, 'status_code': status_code},
            **kwargs
        )


class APITimeoutError(IntegrationError):
    """Raised when API call times out"""
    
    def __init__(self, provider: str, model: str, timeout: int, **kwargs):
        message = f"API timeout: {provider}/{model} after {timeout}s"
        super().__init__(
            message=message,
            error_code=ErrorCode.API_TIMEOUT,
            details={'provider': provider, 'model': model, 'timeout': timeout},
            **kwargs
        )


class APIRateLimitError(IntegrationError):
    """Raised when API rate limit is exceeded"""
    
    def __init__(self, provider: str, retry_after: int = 60, **kwargs):
        message = f"API rate limit exceeded for {provider}, retry after {retry_after}s"
        super().__init__(
            message=message,
            error_code=ErrorCode.API_RATE_LIMITED,
            details={'provider': provider, 'retry_after': retry_after},
            **kwargs
        )


class StreamingError(IntegrationError):
    """Raised when streaming fails"""
    
    def __init__(self, provider: str, reason: str = "", **kwargs):
        message = f"Streaming failed for {provider}"
        if reason:
            message += f": {reason}"
        super().__init__(
            message=message,
            error_code=ErrorCode.STREAMING_ERROR,
            details={'provider': provider, 'reason': reason},
            **kwargs
        )


class ToolError(AgentOSError):
    """Base exception for tool errors"""
    
    def __init__(self, message: str, error_code: ErrorCode = ErrorCode.TOOL_EXECUTION_FAILED, **kwargs):
        super().__init__(message=message, error_code=error_code, **kwargs)


class ToolNotFoundError(ToolError):
    """Raised when tool is not found"""
    
    def __init__(self, tool_name: str, **kwargs):
        message = f"Tool not found: {tool_name}"
        super().__init__(
            message=message,
            error_code=ErrorCode.TOOL_NOT_FOUND,
            details={'tool_name': tool_name},
            **kwargs
        )


class ToolExecutionError(ToolError):
    """Raised when tool execution fails"""
    
    def __init__(self, tool_name: str, exit_code: int = 1, stderr: str = "", **kwargs):
        message = f"Tool execution failed: {tool_name} (exit code: {exit_code})"
        if stderr:
            message += f": {stderr[:200]}"
        super().__init__(
            message=message,
            error_code=ErrorCode.TOOL_EXECUTION_FAILED,
            details={'tool_name': tool_name, 'exit_code': exit_code, 'stderr': stderr},
            **kwargs
        )


class ToolTimeoutError(ToolError):
    """Raised when tool execution times out"""
    
    def __init__(self, tool_name: str, timeout: int, **kwargs):
        message = f"Tool execution timeout: {tool_name} after {timeout}s"
        super().__init__(
            message=message,
            error_code=ErrorCode.TOOL_TIMEOUT,
            details={'tool_name': tool_name, 'timeout': timeout},
            **kwargs
        )


# Utility functions
def get_error_by_code(code: int) -> ErrorCode:
    """Get ErrorCode by code number"""
    for ec in ErrorCode:
        if ec.code == code:
            return ec
    return ErrorCode.UNKNOWN_ERROR


def wrap_exception(exc: Exception, new_message: str = "") -> AgentOSError:
    """Wrap an exception in an AgentOSError"""
    if isinstance(exc, AgentOSError):
        return exc
    
    # Try to determine appropriate error code
    error_code = ErrorCode.UNKNOWN_ERROR
    if "not found" in str(exc).lower():
        error_code = ErrorCode.PAGE_NOT_FOUND
    elif "permission" in str(exc).lower():
        error_code = ErrorCode.PERMISSION_DENIED
    elif "timeout" in str(exc).lower():
        error_code = ErrorCode.API_TIMEOUT
    elif "quota" in str(exc).lower() or "limit" in str(exc).lower():
        error_code = ErrorCode.QUOTA_EXCEEDED
    
    message = new_message or str(exc) if str(exc) else "An error occurred"
    
    return AgentOSError(
        message=message,
        error_code=error_code,
        cause=exc
    )

# Alias for backward compatibility
KernelErrorCode = ErrorCode

# KernelException alias
KernelException = AgentOSError

