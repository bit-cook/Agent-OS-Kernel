# -*- coding: utf-8 -*-
"""
Metrics Module - Prometheus-compatible metrics for Agent OS Kernel
"""

import time
import threading
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field
from collections import defaultdict
from datetime import datetime


@dataclass
class Metric:
    """Individual metric definition"""
    name: str
    value: float
    labels: Dict[str, str] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    metric_type: str = "gauge"  # gauge, counter, histogram


class MetricsCollector:
    """
    Prometheus-compatible metrics collector for Agent OS Kernel
    
    Collects and exposes metrics for monitoring:
    - Token usage (input/output)
    - API call latency
    - Agent lifecycle events
    - Context cache hit rates
    - Queue depths
    - Error rates
    """
    
    def __init__(self, prefix: str = "agent_os"):
        """
        Initialize metrics collector
        
        Args:
            prefix: Metric name prefix
        """
        self.prefix = prefix
        self.metrics: List[Metric] = []
        self.counters: Dict[str, float] = defaultdict(float)
        self.gauges: Dict[str, float] = {}
        self.histograms: Dict[str, List[float]] = defaultdict(list)
        self.lock = threading.Lock()
        
        # Track initialization time
        self.start_time = time.time()
        
    def _make_name(self, name: str) -> str:
        """Create full metric name with prefix"""
        return f"{self.prefix}_{name}"
    
    # ========== Counter Metrics ==========
    
    def increment_counter(self, name: str, value: float = 1.0, labels: Optional[Dict] = None):
        """Increment a counter metric"""
        key = self._make_name(name)
        with self.lock:
            self.counters[key] += value
    
    def get_counter(self, name: str) -> float:
        """Get counter value"""
        key = self._make_name(name)
        return self.counters.get(key, 0.0)
    
    # ========== Gauge Metrics ==========
    
    def set_gauge(self, name: str, value: float, labels: Optional[Dict] = None):
        """Set a gauge metric"""
        key = self._make_name(name)
        with self.lock:
            self.gauges[key] = value
    
    def get_gauge(self, name: str) -> float:
        """Get gauge value"""
        key = self._make_name(name)
        return self.gauges.get(key, 0.0)
    
    def gauge_increment(self, name: str, value: float = 1.0):
        """Increment a gauge metric"""
        key = self._make_name(name)
        with self.lock:
            self.gauges[key] = self.gauges.get(key, 0) + value
    
    def gauge_decrement(self, name: str, value: float = 1.0):
        """Decrement a gauge metric"""
        key = self._make_name(name)
        with self.lock:
            self.gauges[key] = self.gauges.get(key, 0) - value
    
    # ========== Histogram Metrics ==========
    
    def observe_histogram(self, name: str, value: float, labels: Optional[Dict] = None):
        """Record a histogram observation"""
        key = self._make_name(name)
        with self.lock:
            self.histograms[key].append(value)
    
    def get_histogram_percentile(self, name: str, percentile: float = 0.95) -> float:
        """Get histogram percentile value"""
        key = self._make_name(name)
        values = self.histograms.get(key, [])
        if not values:
            return 0.0
        sorted_values = sorted(values)
        idx = int(len(sorted_values) * percentile)
        return sorted_values[min(idx, len(sorted_values) - 1)]
    
    # ========== Agent OS Specific Metrics ==========
    
    def record_token_usage(self, input_tokens: int, output_tokens: int):
        """Record LLM token usage"""
        self.increment_counter("tokens_input_total", input_tokens)
        self.increment_counter("tokens_output_total", output_tokens)
        self.set_gauge("tokens_input_last", input_tokens)
        self.set_gauge("tokens_output_last", output_tokens)
    
    def record_api_call(self, provider: str, latency_ms: float, success: bool):
        """Record API call metrics"""
        self.increment_counter("api_calls_total", 1, {"provider": provider})
        if not success:
            self.increment_counter("api_calls_errors_total", 1, {"provider": provider})
        self.observe_histogram("api_latency_ms", latency_ms, {"provider": provider})
        self.set_gauge("api_latency_last_ms", latency_ms, {"provider": provider})
    
    def record_agent_created(self, agent_name: str):
        """Record agent creation"""
        self.increment_counter("agents_created_total")
        self.gauge_increment("agents_active")
    
    def record_agent_terminated(self, agent_name: str, reason: str = "completed"):
        """Record agent termination"""
        self.increment_counter("agents_terminated_total", labels={"reason": reason})
        self.gauge_decrement("agents_active")
    
    def record_context_cache_hit(self, hit: bool):
        """Record context cache hit/miss"""
        if hit:
            self.increment_counter("context_cache_hits_total")
        else:
            self.increment_counter("context_cache_misses_total")
    
    def record_checkpoint_created(self):
        """Record checkpoint creation"""
        self.increment_counter("checkpoints_created_total")
        self.gauge_increment("checkpoints_active")
    
    def record_checkpoint_restored(self):
        """Record checkpoint restoration"""
        self.increment_counter("checkpoints_restored_total")
        self.gauge_decrement("checkpoints_active")
    
    def record_tool_call(self, tool_name: str, latency_ms: float, success: bool):
        """Record tool execution metrics"""
        self.increment_counter("tool_calls_total", labels={"tool": tool_name})
        if not success:
            self.increment_counter("tool_calls_errors_total", labels={"tool": tool_name})
        self.observe_histogram("tool_latency_ms", latency_ms, {"tool": tool_name})
    
    def record_queue_depth(self, queue_name: str, depth: int):
        """Record queue depth"""
        self.set_gauge(f"queue_{queue_name}_depth", depth)
    
    # ========== Prometheus Format Output ==========
    
    def to_prometheus(self) -> str:
        """Export metrics in Prometheus text format"""
        lines = []
        uptime_seconds = time.time() - self.start_time
        
        # Uptime metric
        lines.append(f"# HELP {self.prefix}_uptime_seconds Uptime in seconds")
        lines.append(f"# TYPE {self.prefix}_uptime_seconds gauge")
        lines.append(f"{self.prefix}_uptime_seconds {uptime_seconds:.2f}")
        lines.append("")
        
        # Counters
        for key, value in self.counters.items():
            metric_name = key.replace(f"{self.prefix}_", "")
            lines.append(f"# HELP {metric_name} Total count")
            lines.append(f"# TYPE {metric_name} counter")
            lines.append(f"{metric_name} {value:.0f}")
            lines.append("")
        
        # Gauges
        for key, value in self.gauges.items():
            metric_name = key.replace(f"{self.prefix}_", "")
            lines.append(f"# HELP {metric_name} Current value")
            lines.append(f"# TYPE {metric_name} gauge")
            lines.append(f"{metric_name} {value:.2f}")
            lines.append("")
        
        # Histograms
        for key, values in self.histograms.items():
            if not values:
                continue
            metric_name = key.replace(f"{self.prefix}_", "")
            lines.append(f"# HELP {metric_name} Latency histogram")
            lines.append(f"# TYPE {metric_name} histogram")
            
            sorted_values = sorted(values)
            for percentile in [0.5, 0.9, 0.95, 0.99]:
                idx = int(len(sorted_values) * percentile)
                percentile_value = sorted_values[min(idx, len(sorted_values) - 1)]
                lines.append(f"{metric_name}_percentile{{{self.prefix}_percentile=\"{percentile*100:.0f}\"}} {percentile_value:.2f}")
            
            lines.append(f"{metric_name}_count {len(values)}")
            lines.append(f"{metric_name}_sum {sum(values):.2f}")
            lines.append("")
        
        return "\n".join(lines)
    
    def to_json(self) -> Dict[str, Any]:
        """Export metrics in JSON format"""
        uptime_seconds = time.time() - self.start_time
        
        return {
            "timestamp": datetime.utcnow().isoformat(),
            "uptime_seconds": uptime_seconds,
            "counters": dict(self.counters),
            "gauges": dict(self.gauges),
            "histograms": {
                k: {
                    "count": len(v),
                    "sum": sum(v),
                    "percentiles": {
                        "p50": self.get_histogram_percentile(k.replace(f"{self.prefix}_", ""), 0.5),
                        "p90": self.get_histogram_percentile(k.replace(f"{self.prefix}_", ""), 0.9),
                        "p95": self.get_histogram_percentile(k.replace(f"{self.prefix}_", ""), 0.95),
                        "p99": self.get_histogram_percentile(k.replace(f"{self.prefix}_", ""), 0.99),
                    }
                }
                for k, v in self.histograms.items()
            }
        }
    
    def reset(self):
        """Reset all metrics (except start time)"""
        with self.lock:
            self.counters.clear()
            self.gauges.clear()
            self.histograms.clear()


class MetricsMiddleware:
    """
    WSGI middleware for exposing metrics
    
    Add to your Flask app:
        app.wsgi_app = MetricsMiddleware(app.wsgi_app, metrics)
    """
    
    def __init__(self, app, metrics: MetricsCollector, path: str = "/metrics"):
        self.app = app
        self.metrics = metrics
        self.path = path
    
    def __call__(self, environ, start_response):
        if environ.get('PATH_INFO') == self.path:
            output = self.metrics.to_prometheus()
            start_response('200 OK', [('Content-Type', 'text/plain')])
            return [output.encode('utf-8')]
        return self.app(environ, start_response)


# Global metrics instance
default_metrics = MetricsCollector()


# Convenience functions
def get_metrics() -> MetricsCollector:
    """Get the default metrics collector"""
    return default_metrics
