# -*- coding: utf-8 -*-
"""
OpenAI Integration - OpenAI GPT API Integration for Agent OS Kernel

Full support for GPT-4, GPT-3.5, function calling, and streaming.
"""

import json
import time
import logging
from typing import Dict, Any, Optional, List, Generator
from dataclasses import dataclass

logger = logging.getLogger(__name__)


# Check for dependencies
OPENAI_AVAILABLE = False
try:
    import openai
    OPENAI_AVAILABLE = True
except ImportError:
    logger.warning("openai package not installed. OpenAI integration will use mock mode.")
    logger.warning("Install with: pip install openai")


@dataclass
class OpenAIConfig:
    """OpenAI configuration"""
    api_key: str = ""
    model: str = "gpt-4"
    max_tokens: int = 4000
    temperature: float = 0.7
    top_p: float = 1.0
    stream: bool = True
    timeout: int = 60
    max_retries: int = 3


class OpenAIIntegratedKernel:
    """
    OpenAI API Integration for Agent OS Kernel
    
    Features:
    - Support for GPT-4, GPT-3.5-turbo
    - Function calling (Tools)
    - Streaming responses
    - Automatic retry with exponential backoff
    - Token usage tracking
    """
    
    DEFAULT_SYSTEM_TEMPLATE = """You are an AI agent running in an Agent OS Kernel environment.

Your name: {name}
Your task: {task}

Available tools:
{tools}

Think step by step and respond in the following JSON format:

{{
    "reasoning": "Your step-by-step thinking process",
    "action": {{
        "tool": "tool_name",
        "parameters": {{"param1": "value1"}}
    }},
    "done": false
}}

If the task is complete, set "done" to true and omit the "action" field.
"""
    
    def __init__(self, 
                 config: Optional[OpenAIConfig] = None,
                 **kwargs):
        """
        Initialize OpenAI integration
        
        Args:
            config: OpenAI configuration
            **kwargs: Configuration options (overrides config)
        """
        self.config = config or OpenAIConfig()
        
        # Apply kwargs overrides
        for key, value in kwargs.items():
            if hasattr(self.config, key):
                setattr(self.config, key, value)
        
        # Initialize client
        self.client = None
        self._init_client()
        
        # Conversation history cache
        self.conversation_cache: Dict[str, List[Dict]] = {}
        
        logger.info(f"[OpenAI] Initialized with model: {self.config.model}")
    
    def _init_client(self):
        """Initialize OpenAI client"""
        if not OPENAI_AVAILABLE:
            logger.warning("[OpenAI] Using mock mode (no API key or package)")
            return
        
        api_key = self.config.api_key or self._get_api_key()
        
        if not api_key:
            logger.warning("[OpenAI] No API key provided, using mock mode")
            return
        
        try:
            self.client = openai.OpenAI(api_key=api_key)
            self.client.api_key = api_key
            logger.info("[OpenAI] Client initialized successfully")
        except Exception as e:
            logger.error(f"[OpenAI] Failed to initialize client: {e}")
            self.client = None
    
    def _get_api_key(self) -> str:
        """Get API key from environment or config"""
        import os
        return os.environ.get("OPENAI_API_KEY", "")
    
    def chat_completion(self, 
                      messages: List[Dict[str, str]],
                      functions: Optional[List[Dict]] = None,
                      stream: bool = None) -> Dict[str, Any]:
        """
        Send chat completion request
        
        Args:
            messages: List of message objects
            functions: Optional function definitions for tool calling
            stream: Override streaming setting
        
        Returns:
            Response dictionary with content and usage
        """
        stream = stream if stream is not None else self.config.stream
        
        if not self.client:
            return self._mock_completion(messages)
        
        try:
            # Prepare request
            request_params = {
                "model": self.config.model,
                "messages": messages,
                "max_tokens": self.config.max_tokens,
                "temperature": self.config.temperature,
                "top_p": self.config.top_p,
            }
            
            # Add functions if provided
            if functions:
                request_params["functions"] = functions
                request_params["function_call"] = "auto"
            
            # Handle streaming
            if stream:
                return self._stream_completion(request_params)
            else:
                return self._non_stream_completion(request_params)
                
        except openai.RateLimitError as e:
            logger.warning(f"[OpenAI] Rate limit, retrying: {e}")
            return self._retry_with_backoff(lambda: self._non_stream_completion(request_params))
        
        except Exception as e:
            logger.error(f"[OpenAI] API error: {e}")
            return self._mock_completion(messages)
    
    def _non_stream_completion(self, params: Dict) -> Dict[str, Any]:
        """Handle non-streaming completion"""
        response = self.client.chat.completions.create(**params)
        
        choice = response.choices[0]
        message = choice.message
        
        result = {
            "content": message.content or "",
            "role": message.role,
        }
        
        # Handle function call
        if message.function_call:
            result["function_call"] = {
                "name": message.function_call.name,
                "arguments": message.function_call.arguments
            }
        
        # Token usage
        if response.usage:
            result["usage"] = {
                "prompt_tokens": response.usage.prompt_tokens,
                "completion_tokens": response.usage.completion_tokens,
                "total_tokens": response.usage.total_tokens
            }
        
        return result
    
    def _stream_completion(self, params: Dict) -> Dict[str, Any]:
        """Handle streaming completion"""
        params["stream"] = True
        
        response = self.client.chat.completions.create(**params)
        
        chunks = []
        content = ""
        
        for chunk in response:
            if chunk.choices[0].delta.content:
                chunk_content = chunk.choices[0].delta.content
                chunks.append(chunk_content)
                content += chunk_content
        
        return {
            "content": content,
            "chunks": chunks,
            "role": "assistant",
            "stream": True
        }
    
    def _retry_with_backoff(self, func, retries: int = None):
        """Retry with exponential backoff"""
        retries = retries or self.config.max_retries
        base_delay = 1.0
        
        for attempt in range(retries):
            try:
                return func()
            except Exception as e:
                delay = base_delay * (2 ** attempt)
                logger.warning(f"[OpenAI] Retry {attempt + 1}/{retries} after {delay}s: {e}")
                time.sleep(delay)
        
        logger.error(f"[OpenAI] All retries failed")
        return {"error": "max_retries_exceeded", "content": ""}
    
    def _mock_completion(self, messages: List[Dict]) -> Dict[str, Any]:
        """Mock completion for testing without API key"""
        last_message = messages[-1].get("content", "") if messages else ""
        
        return {
            "content": f"Mock response to: {last_message[:100]}...",
            "role": "assistant",
            "mock": True
        }
    
    def update_conversation_cache(self, agent_pid: str, 
                                messages: List[Dict]):
        """Update conversation cache for KV-Cache optimization"""
        if agent_pid not in self.conversation_cache:
            self.conversation_cache[agent_pid] = []
        
        # Add new messages (keep last 20 for context)
        self.conversation_cache[agent_pid] = self.conversation_cache[agent_pid][-20:] + messages
    
    def get_conversation_history(self, agent_pid: str) -> List[Dict]:
        """Get conversation history for agent"""
        return self.conversation_cache.get(agent_pid, [])
    
    def extract_function_calls(self, response: Dict) -> Optional[Dict]:
        """Extract and parse function call from response"""
        if "function_call" in response:
            return response["function_call"]
        return None
    
    def create_tool_result_message(self, 
                                tool_name: str,
                                result: Any) -> Dict:
        """Create tool result message for function calling"""
        return {
            "role": "user",
            "content": json.dumps({
                "tool": tool_name,
                "result": result
            })
        }
    
    def get_embedding(self, text: str) -> List[float]:
        """Get text embedding using OpenAI embeddings API"""
        if not self.client:
            return [0.0] * 1536  # Mock embedding
        
        try:
            response = self.client.embeddings.create(
                model="text-embedding-3-small",
                input=text
            )
            return response.data[0].embedding
        except Exception as e:
            logger.error(f"[OpenAI] Embedding error: {e}")
            return [0.0] * 1536


# Convenience function
def create_openai_kernel(config: Optional[OpenAIConfig] = None) -> OpenAIIntegratedKernel:
    """Create OpenAI integrated kernel"""
    return OpenAIIntegratedKernel(config)
