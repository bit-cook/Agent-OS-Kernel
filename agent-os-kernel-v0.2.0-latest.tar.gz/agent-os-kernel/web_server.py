# -*- coding: utf-8 -*-
"""
Agent-OS-Kernel Web Server
整合 REST API 和 Web UI
"""

import logging
from flask import Flask, send_from_directory, jsonify, request

from agent_os_kernel import AgentOSKernel, __version__, MetricsCollector, get_metrics

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__, 
           static_folder='web/static',
           template_folder='web/templates')

# 全局实例
_kernel = None
_metrics = None

def get_kernel():
    """获取或创建内核实例"""
    global _kernel, _metrics
    if _kernel is None:
        _kernel = AgentOSKernel()
        _metrics = get_metrics()
        logger.info("Agent-OS-Kernel 初始化完成")
    return _kernel

def get_metrics():
    """获取指标收集器"""
    global _metrics
    if _metrics is None:
        _metrics = MetricsCollector()
    return _metrics

# ========== API 端点 ==========

@app.route('/')
def index():
    """Web UI 首页"""
    return send_from_directory(app.template_folder, 'console.html')


@app.route('/api')
def api_index():
    """API 信息"""
    return jsonify({
        'name': 'Agent-OS-Kernel API',
        'version': __version__,
        'endpoints': {
            'GET /': 'Web UI',
            'GET /health': '健康检查',
            'GET /api/kernel': '内核状态',
            'POST /api/agent': '创建 Agent',
            'GET /api/agent/<pid>': 'Agent 状态',
            'DELETE /api/agent/<pid>': '终止 Agent',
            'POST /api/checkpoint': '创建检查点',
            'POST /api/restore': '恢复检查点',
            'GET /api/metrics': 'Prometheus 指标',
            'GET /api/metrics/json': 'JSON 指标',
            'GET /api/tools': '工具列表',
            'POST /api/tool/<name>': '执行工具',
        }
    })


@app.route('/health')
def health():
    """健康检查"""
    return jsonify({
        'status': 'ok',
        'service': 'agent-os-kernel-web'
    })


@app.route('/api/kernel', methods=['GET'])
def kernel_status():
    """内核状态"""
    k = get_kernel()
    m = get_metrics()
    return jsonify({
        'version': __version__,
        'agents_count': len(k.scheduler.processes),
        'uptime_seconds': m.to_json().get('uptime_seconds', 0)
    })


@app.route('/api/agent', methods=['POST'])
def create_agent():
    """创建 Agent"""
    data = request.get_json(silent=True) or {}
    k = get_kernel()
    
    pid = k.spawn_agent(
        name=data.get('name', f'WebAgent-{len(k.scheduler.processes)}'),
        task=data.get('task', 'Web created agent'),
        priority=data.get('priority', 50)
    )
    
    logger.info(f"Web 创建 Agent: {pid}")
    return jsonify({'success': True, 'pid': pid})


@app.route('/api/agent/<pid>', methods=['GET'])
def get_agent(pid):
    """Agent 状态"""
    k = get_kernel()
    status = k.get_agent_status(pid)
    if status:
        return jsonify({'success': True, 'status': status})
    return jsonify({'success': False, 'error': 'Agent not found'}), 404


@app.route('/api/agent/<pid>', methods=['DELETE'])
def terminate_agent(pid):
    """终止 Agent"""
    k = get_kernel()
    k.terminate_agent(pid)
    return jsonify({'success': True, 'pid': pid})


@app.route('/api/checkpoint', methods=['POST'])
def create_checkpoint():
    """创建检查点"""
    data = request.get_json(silent=True) or {}
    k = get_kernel()
    cp_id = k.create_checkpoint(data.get('pid'), data.get('description', 'Web checkpoint'))
    return jsonify({'success': True, 'checkpoint_id': cp_id})


@app.route('/api/restore', methods=['POST'])
def restore_checkpoint():
    """恢复检查点"""
    data = request.get_json(silent=True) or {}
    k = get_kernel()
    new_pid = k.restore_checkpoint(data.get('checkpoint_id'))
    return jsonify({'success': True, 'new_pid': new_pid})


@app.route('/api/metrics')
def get_prometheus():
    """Prometheus 格式指标"""
    m = get_metrics()
    return m.to_prometheus(), 200, {'Content-Type': 'text/plain'}


@app.route('/api/metrics/json')
def get_json_metrics():
    """JSON 格式指标"""
    m = get_metrics()
    return jsonify(m.to_json())


@app.route('/api/tools')
def list_tools():
    """工具列表"""
    k = get_kernel()
    return jsonify({'success': True, 'tools': k.tool_registry.list_tools()})


@app.route('/api/tool/<name>', methods=['POST'])
def execute_tool(name):
    """执行工具"""
    k = get_kernel()
    params = request.get_json(silent=True) or {}
    result = k.execute_tool(name, **params)
    return jsonify({'success': True, 'tool': name, 'result': result})


# ========== 静态文件 ==========

@app.route('/static/<path:filename>')
def serve_static(filename):
    """静态文件服务"""
    return send_from_directory(app.static_folder, filename)


# ========== 错误处理 ==========

@app.errorhandler(Exception)
def handle_error(e):
    logger.error(f"Web Server Error: {e}")
    return jsonify({'success': False, 'error': str(e)}), 500


# ========== 启动 ==========

def main():
    from argparse import ArgumentParser
    
    parser = ArgumentParser(description='Agent-OS-Kernel Web Server')
    parser.add_argument('--host', default='0.0.0.0', help='绑定地址')
    parser.add_argument('--port', type=int, default=8090, help='端口')
    parser.add_argument('--debug', action='store_true', help='调试模式')
    
    args = parser.parse_args()
    
    print(f"\n{'='*60}")
    print("Agent-OS-Kernel Web Server")
    print(f"{'='*60}")
    print(f"Web UI:   http://{args.host}:{args.port}/")
    print(f"API:      http://{args.host}:{args.port}/api")
    print(f"Health:   http://{args.host}:{args.port}/health")
    print(f"{'='*60}\n")
    
    app.run(host=args.host, port=args.port, debug=args.debug)


if __name__ == '__main__':
    main()

@app.route('/<filename>')
def download_file(filename):
    """文件下载"""
    import os
    if filename.endswith('.tar.gz') or filename.endswith('.zip'):
        return send_from_directory('.', filename, as_attachment=True)
    return send_from_directory('.', filename)
