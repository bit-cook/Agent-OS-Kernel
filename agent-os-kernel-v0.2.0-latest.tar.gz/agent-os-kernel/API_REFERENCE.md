# Agent-OS-Kernel API 参考

## 核心类

### AgentOSKernel

主内核类，管理所有子系统。

```python
from agent_os_kernel import AgentOSKernel

kernel = AgentOSKernel(config=None)
```

#### 方法

| 方法 | 描述 | 参数 |
|------|------|------|
| `spawn_agent(name, task, priority)` | 创建新 Agent | name: str, task: str, priority: int |
| `get_agent_status(pid)` | 获取 Agent 状态 | pid: str |
| `terminate_agent(pid)` | 终止 Agent | pid: str |
| `create_checkpoint(pid, description)` | 创建检查点 | pid: str, description: str |
| `restore_checkpoint(checkpoint_id)` | 从检查点恢复 | checkpoint_id: str |
| `run(max_iterations)` | 运行内核 | max_iterations: int |
| `execute_tool(name, **kwargs)` | 执行工具 | name: str, **kwargs |

#### 属性

| 属性 | 类型 | 描述 |
|------|------|------|
| `version` | str | 内核版本 |
| `context_manager` | ContextManager | 上下文管理器 |
| `scheduler` | AgentScheduler | 调度器 |
| `storage` | StorageManager | 存储管理器 |
| `tool_registry` | ToolRegistry | 工具注册表 |
| `metrics` | MetricsCollector | 指标收集器 |
| `sandbox` | SandboxManager | 沙箱管理器 |

---

## Context Manager (上下文管理)

```python
from agent_os_kernel import ContextManager

ctx = ContextManager(max_tokens=128000)
```

### 方法

| 方法 | 描述 |
|------|------|
| `allocate_page(agent_pid, content, importance, page_type)` | 分配上下文页面 |
| `access_page(page_id)` | 访问页面 |
| `get_agent_context(agent_pid)` | 获取 Agent 完整上下文 |
| `release_agent_pages(agent_pid)` | 释放 Agent 所有页面 |
| `swap_out_least_important()` | 换出不重要页面 |

---

## Scheduler (调度器)

```python
from agent_os_kernel import AgentScheduler

scheduler = AgentScheduler(time_slice=60.0)
```

### 方法

| 方法 | 描述 |
|------|------|
| `add_process(process)` | 添加进程 |
| `schedule()` | 调度下一个进程 |
| `yield_process(pid)` | 让出 CPU |
| `terminate_process(pid, reason)` | 终止进程 |
| `get_active_processes()` | 获取活跃进程列表 |

---

## Storage (存储)

```python
from agent_os_kernel import StorageManager

storage = StorageManager(backend="memory")  # 或 "postgresql://..."
```

### 支持的存储后端

- `memory` - 内存存储（默认）
- `postgresql://...` - PostgreSQL 连接字符串

### 方法

| 方法 | 描述 |
|------|------|
| `save_memory(key, data)` | 保存记忆 |
| `retrieve_memories(query)` | 检索记忆 |
| `save_process(pid, state)` | 保存进程状态 |
| `load_process(pid)` | 加载进程状态 |
| `save_checkpoint(checkpoint)` | 保存检查点 |
| `load_checkpoint(checkpoint_id)` | 加载检查点 |

---

## Metrics (指标收集)

```python
from agent_os_kernel import MetricsCollector

metrics = MetricsCollector(prefix="agent_os")
```

### 方法

| 方法 | 描述 |
|------|------|
| `record_api_call(provider, latency_ms, success)` | 记录 API 调用 |
| `record_token_usage(input_tokens, output_tokens)` | 记录 Token 使用 |
| `record_agent_created(name)` | 记录 Agent 创建 |
| `record_agent_terminated(name, reason)` | 记录 Agent 终止 |
| `record_context_cache_hit(hit)` | 记录缓存命中 |
| `record_tool_call(name, latency_ms, success)` | 记录工具调用 |
| `to_prometheus()` | 导出 Prometheus 格式 |
| `to_json()` | 导出 JSON 格式 |

---

## 工具函数

### Token 估算

```python
from agent_os_kernel.utils import estimate_tokens, estimate_tokens_messages

# 单文本
tokens = estimate_tokens("Hello World")  # ~3 tokens

# 消息列表
messages = [
    {"role": "user", "content": "Hello"},
    {"role": "assistant", "content": "Hi!"}
]
tokens = estimate_tokens_messages(messages)
```

### 文本处理

```python
from agent_os_kernel.utils import truncate_text, normalize_whitespace

# 截断文本
truncated = truncate_text(long_text, max_tokens=100)

# 规范化空白
normalized = normalize_whitespace("  Hello   World  ")
# 结果: "Hello World"
```

### JSON 处理

```python
from agent_os_kernel.utils import parse_json_safely, format_json

# 安全解析 JSON
data, error = parse_json_safely('{"key": "value"}')

# 格式化 JSON
formatted = format_json(data, indent=2)
```

### ID 生成

```python
from agent_os_kernel.utils import (
    generate_id,
    generate_session_id,
    generate_agent_id,
    generate_checkpoint_id
)

id1 = generate_id()              # "abc12345"
id2 = generate_session_id()       # "session-abc12345"
id3 = generate_agent_id()         # "agent-abc12345"
id4 = generate_checkpoint_id()   # "cp-abc12345"
```

### 时间处理

```python
from agent_os_kernel.utils import format_duration, format_timestamp

# 格式化时长
format_duration(3661)   # "1h 1m 1s"
format_duration(90)    # "1m 30s"

# 格式化时间戳
format_timestamp(format="iso")    # "2024-02-06T19:00:00"
format_timestamp(format="human")  # "2024-02-06 19:00:00"
```

---

## 异常处理

```python
from agent_os_kernel.core.exceptions import (
    KernelException,
    KernelErrorCode,
    ContextError,
    StorageError,
    SchedulerError,
    ToolError,
    SecurityError
)

try:
    # 可能抛出异常的代码
    pass
except KernelException as e:
    print(f"错误码: {e.error_code.name}")
    print(f"消息: {e.message}")
    print(f"详情: {e.details}")
```

### 错误码

| 类别 | 前缀 | 示例 |
|------|------|------|
| Context | CTX_ | CTX_OVERFLOW, CTX_SWAP_FAILED |
| Storage | STO_ | STO_CONNECTION_FAILED, STO_WRITE_ERROR |
| Scheduler | SCH_ | SCH_DEADLOCK, SCH_TIMEOUT |
| Tool | TOL_ | TOL_NOT_FOUND, TOL_EXEC_FAILED |
| Security | SEC_ | SEC_PERMISSION_DENIED |
| API | API_ | API_RATE_LIMIT, API_TIMEOUT |

---

## 配置

```python
from agent_os_kernel.core.config import KernelConfig

config = KernelConfig()

# 从字典创建
config = KernelConfig.from_dict({
    'context': {'max_context_tokens': 64000},
    'scheduler': {'time_slice': 30.0}
})

# 获取嵌套值
max_tokens = config.get_nested('context.max_context_tokens')

# 转换为字典
config_dict = config.to_dict()
```

### 默认配置

```python
DEFAULT_CONFIG = {
    'context': {
        'max_context_tokens': 128000,
        'min_context_tokens': 1000,
    },
    'scheduler': {
        'time_slice': 60.0,
        'max_concurrent_agents': 10,
    },
    'metrics': {
        'enabled': True,
        'port': 9090,
    },
    'logging': {
        'level': 'INFO',
    },
    'security': {
        'enable_sandbox': False,
    }
}
```

---

## 环境变量

| 变量 | 描述 | 默认值 |
|------|------|--------|
| AGENT_OS_CONTEXT_TOKENS | 最大上下文 Token 数 | 128000 |
| AGENT_OS_TIME_SLICE | 调度时间片 | 60.0 |
| AGENT_OS_MAX_AGENTS | 最大并发 Agent 数 | 10 |
| AGENT_OS_STORAGE_TYPE | 存储类型 | memory |
| AGENT_OS_LOG_LEVEL | 日志级别 | INFO |
| AGENT_OS_METRICS_PORT | 指标端口 | 9090 |
